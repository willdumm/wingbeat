# Wingbeat Design System

Wingbeat is a **flight tracker**: you give it a flight number, a route or an airport, and it tells you where the aircraft is and when it will actually arrive. Its defining product promise is restraint — one notification when something changes, not a feed to scroll.

This repository is the design system for that product: tokens, brand assets, reusable React primitives, and click-through recreations of the two surfaces (iOS app, marketing web).

## Sources given

| Source | What it contained |
| --- | --- |
| `uploads/logo_plain.svg` | The Wingbeat mark — two rounded arcs forming a bird in flight / a wingbeat. Left wing black `#000000`, right wing blue `#2b7fc4`. 120×40 mm artboard. This is the **only** visual artefact supplied. |
| Brief (chat) | "Wingbeat flight tracker." Direction: *"modern, sans serif fonts, and simple, light colors."* |

No codebase, Figma file, screenshots, decks, product copy or font binaries were provided. Everything beyond the mark — palette beyond the logo blue, type, spacing, component inventory, copy voice, both UI kits — was **derived from the mark and the brief**, not recovered from an existing product. Treat it as a proposal to correct, not a record of what exists. Every substitution is flagged under [Caveats](#caveats).

---

## Index

| Path | What it is |
| --- | --- |
| `styles.css` | The one file consumers link. `@import` list only. |
| `tokens/` | `fonts.css`, `colors.css`, `typography.css`, `spacing.css`, `radius.css`, `elevation.css`, `motion.css`, `base.css`, `utilities.css` |
| `components/components.css` | Class layer behind the React primitives (`wb-*`), all values from tokens |
| `components/core/` | Button, IconButton, Icon, Badge, Tag, Card, CardHeader |
| `components/forms/` | Field, Input, Select, Checkbox, Radio, Switch |
| `components/navigation/` | Tabs |
| `components/feedback/` | Dialog, Toast, Tooltip |
| `components/flight/` | FlightStatusBadge, FlightProgress, Stat, FlightCard |
| `components/brand/` | Logo |
| `guidelines/cards/` | 18 foundation specimen cards (Colors, Type, Spacing, Brand) |
| `ui_kits/mobile_app/` | Wingbeat for iOS — live map, watchlist, airports, flight detail, alerts |
| `ui_kits/web/` | Wingbeat.com — search hero, features, live board, CTA, footer |
| `assets/` | Logo mark in four tones |
| `SKILL.md` | Agent Skills front matter for use outside this project |

### Components

Twenty-two exports, all reachable on the compiled namespace:

**Core** — `Button`, `IconButton`, `Icon`, `Badge`, `Tag`, `Card`, `CardHeader`
**Forms** — `Field`, `Input`, `Select`, `Checkbox`, `Radio`, `Switch`
**Navigation** — `Tabs`
**Feedback** — `Dialog`, `Toast`, `Tooltip`
**Flight** — `FlightStatusBadge`, `FlightProgress`, `Stat`, `FlightCard`
**Brand** — `Logo`

Each directory has a `<Name>.jsx`, a `<Name>.d.ts` props contract, a `<Name>.prompt.md` usage note, and one `@dsCard` HTML showing its states.

#### Intentional additions
No source defined a component inventory, so the standard set was authored. Five entries go beyond it, each because the product cannot be drawn without them:

- `Icon` — a Lucide wrapper, so no screen ever hand-rolls an SVG.
- `FlightStatusBadge` — owns the six-word status vocabulary and its colours.
- `FlightProgress` — the route bar (codes, track, plane position).
- `Stat` — the label-over-mono-figure pair used for all telemetry.
- `FlightCard` — the watchlist unit, composed from the four above.

---

## Content fundamentals

**Voice.** Plain, specific, slightly clipped. Wingbeat reports facts about an aircraft; it never sells the feeling of travel. Where a sentence could carry an adjective or a number, it carries the number.

**Person.** Talk to the user as *you*. The product is *we* only when it is doing something on their behalf ("We'll alert you on gate and delay changes"). Never *I*. Never the brand name as a subject in UI copy — "Wingbeat is tracking your flight" belongs on the marketing page, not in the app.

**Casing.** Sentence case everywhere: headlines, buttons, nav, dialog titles, toast titles. The only uppercase in the system is (a) IATA/ICAO identifiers, which are data — `LHR`, `BA117`, `G-VIIL`, `FL340` — and (b) the 11px overline labels above figures (`GROUND SPEED`).

**Numbers and identifiers.** Always monospace, always exactly as aviation writes them: 24-hour times (`14:50`), IATA codes for airports, flight numbers with no space (`BA117`), delays in minutes up to 59 then hours (`22 min`, `1h 10m`), altitudes as flight level in data contexts (`FL340`) and feet in labelled stats (`34,000 ft`).

**Status words are fixed.** In air · Scheduled · On time · Delayed · Cancelled · Landed. No synonyms, no "En route", no "Approaching". If a state isn't one of those six, it isn't shown.

**Notifications state the change, not the app's behaviour.**
- Yes: "BA117 now 22 min late — new departure 14:52, Gate B12"
- Yes: "AF1281 has landed — arrived 09:52 at BCN, 8 minutes early"
- No: "Alert sent", "Flight updated", "Something changed with your flight"

**Buttons are verb phrases at the size of the action**: "Track flight", "Alert me", "Stop tracking", "Get the app". Never "Submit", "OK", "Learn more".

**Marketing headlines are one short declarative sentence**, ending in a full stop: "Know where the plane is." "Put the arrival time in your pocket." Subheads add the mechanism in one sentence and one number.

**Empty and error states name the next move**: "No flights tracked yet — search a flight number to start." Errors are the user's problem to solve, so they say what to do: "Pick a destination airport."

**No emoji.** Not in UI, not in notifications, not in marketing. Status is carried by the chip colour and its word.

**Never**: exclamation marks, "seamless / effortless / powerful", rhetorical questions as headlines, "this, not that" constructions, the word "journey" for a flight.

---

## Visual foundations

### Colour
Three families, all in `tokens/colors.css`.

- **Sky** — the primary ramp, built outward from the logo blue as `--sky-500: #2B7FC4`. The route track, selected rows, links, the CTA band. Filled controls with white labels (`--action-primary`) use **sky-600**, one step darker: white on sky-500 is only 4.25:1.
- **Ink** — cool-leaning neutrals (`#0F1A24` → `#F5F7F9`) for text, hairlines and the page ground. Never a pure black or a warm grey. `--text-subtle` (ink-400, 3.5:1 on white) is for disabled and decorative text only; anything a reader needs is `--text-muted` or stronger.
- **Dusk** — a single warm accent, `#F07D26`. It has exactly three jobs: the pulsing *live* dot, the notification counter, and the marketing "Get the app" CTA. If a fourth use appears, it's a mistake.

Status colours are a closed set: green `#17916B` on time, amber `#C9820A` delayed, red `#D0453B` cancelled, slate `#566574` scheduled/landed, dusk for in-air. Always a tinted background plus the darkest tone of the same hue as text (≥4.5:1), never coloured text on white alone.

Backgrounds are **light and flat**: `--surface-page` is ink-50, cards are white. There are **no decorative gradients**. The only gradients in the system are functional scrims (`--scrim-bottom`, `--scrim-top`) that protect white labels over the map, and the sky-tinted radial haze on the map ground. No dark mode is defined yet.

### Type
- **Manrope** — display, headings, all UI labels and buttons. 800 for hero and display, 700 for H1/H2, 600 for H3 and controls. Negative tracking at size (`-0.025em` display, `-0.015em` headings).
- **IBM Plex Sans** — running body copy only, 16/1.65 default and 14/1.5 compact, never above 18px.
- **IBM Plex Mono** — every identifier, time, coordinate and figure, tabular, `0.02em` tracking. This is the system's strongest signature: if it's data, it's mono.

Scale: 64 / 48 / 36 / 28 / 22 / 18 / 16 / 14 / 13 / 12 / 11. Overlines are 11px 700 uppercase at `0.09em`.

### Space and layout
4px base. `--space-5` (20) and `--space-7` (28) are real steps: card padding is 20, list rows sit on a 28px rhythm. Mobile gutter 20, web gutter 32, content max 1200, prose max 64ch. Web sections are separated by 80px (`--gap-section` 64 inside cards-to-cards groups). Fixed elements: the mobile header and tab bar (both frosted), the web header (sticky, frosted), and the detail card on the board (`position: sticky`).

### Shape
Radii: 4 (checkbox) · 6 (tags, small chips) · 10 (controls, inputs, buttons) · 14 (cards) · 20 (dialogs) · 28 (bottom sheets) · full (status chips, counters, the switch). Cards are white, 14px radius, 1px `--border-subtle` hairline **plus** `--shadow-sm` — both, not one or the other. Raised cards drop the border and take `--shadow-md`.

### Elevation and shadows
All shadows are tinted with sky-900 at 4–12% alpha, short-offset and soft — never black, never more than 28px of blur. Inner shadows are used once (`--shadow-inset-top`) and are optional. Coloured shadows (`--shadow-brand`, `--shadow-accent`) appear only under an active map marker.

### Transparency and blur
Glass (`--glass-bg` white at 82% + `blur(14px) saturate(1.1)`) is reserved for **chrome floating over the live map or scrolling content**: the mobile header, the tab bar, map control buttons, the web header. It is never used on a card, a dialog, or anything over a flat background — over white it reads as a rendering bug.

Over the map and any photography, white text sits on a **scrim gradient**, not a capsule — except for the small mono position labels under aircraft markers, which use a glass capsule because a scrim would fight the marker.

### Motion
Short and level. 80ms on transforms, 140ms on colour, 220ms on surfaces, 360ms on the route bar fill, 420ms for a sheet. Standard easing is `cubic-bezier(0.32, 0.72, 0.28, 1)` — quick out, long settle. **Nothing bounces, nothing overshoots, nothing spins.** Dialogs fade the scrim and rise 8px. The only looping animation in the system is the 1.8s pulse on the live status dot. All of it collapses under `prefers-reduced-motion`.

### States
- **Hover** — fills go one step darker (sky-600 → sky-700); quiet controls take an ink-50 wash; cards lift `-2px` and gain `--shadow-md`. Never opacity fades.
- **Press** — one step darker again (sky-800) plus `scale(0.985)`. A settle, not a squash.
- **Focus** — a solid 2px sky-500 ring outside a 2px page-colour gap (`--ring-focus`), always visible on keyboard focus, never removed. It replaced a 45% sky-400 glow that was too faint to see (~1.5:1).
- **Disabled** — ink-100 fill, ink-400 text, no border, no shadow, `cursor: not-allowed`.
- **Selected** — sky-50 background plus sky-300 border; in tables, the row background alone.

### Imagery
There is no photography in the system yet and none was supplied. Where product screenshots or aviation photography are added, the direction is **cool, bright and daylit** — blue-hour and overcast rather than golden-hour, no grain, no filters, no duotone. The map is the brand's hero image: light sky-tinted land, sky-100 graticule, dashed great-circle arcs, and one accent-coloured aircraft.

---

## Iconography

**System: [Lucide](https://lucide.dev) at 2px stroke** — loaded from CDN (`https://unpkg.com/lucide@0.454.0/dist/umd/lucide.js`) and wrapped by the `Icon` component. This is a **flagged substitution**: no icon font, sprite or SVG set was supplied, so Lucide was chosen for its even 2px stroke and rounded caps, which match the logo's rounded arc terminals.

- Sizes: 16 inline with text, 20 in controls (default), 22–24 in nav and map markers. Never below 16.
- Stroke weight is always 2. Do not thin, fill, or duotone a Lucide glyph.
- Icons are `currentColor` — they inherit the text colour of the control they sit in.
- Common glyphs: `plane`, `plane-takeoff`, `plane-landing`, `map-pin`, `bell`, `bell-off`, `clock`, `gauge`, `radio`, `layers`, `crosshair`, `bookmark`, `bookmark-check`, `search`, `share-2`, `chevron-right`, `chevron-down`, `triangle-alert`, `building-2`, `refresh-cw`.
- **No emoji, ever.** **No unicode glyphs as icons**, with two exceptions that are typography rather than iconography: the arrow in route labels (`LHR → JFK`) and the middot separating data (`FL340 · 494 kt`).
- Never hand-roll an SVG icon. If Lucide lacks the glyph, ask for artwork.

### Logo
`assets/` holds the supplied mark in four tones — `logo-mark.svg` (as delivered), `logo-mark-mono-ink.svg`, `logo-mark-mono-white.svg`, `logo-mark-mono-blue.svg` — plus the `Logo` component, which pairs the mark with the wordmark in Manrope ExtraBold. Geometry is copied verbatim from `uploads/logo_plain.svg` and must never be redrawn. Clear space is at least the mark's height on all sides. Over the map or imagery, use `mono-white` on a scrim.

---

## Caveats

1. **Fonts are substitutes.** No binaries were supplied. Manrope, IBM Plex Sans and IBM Plex Mono are loaded from Google Fonts in `tokens/fonts.css`. Send the licensed files and this becomes a set of local `@font-face` rules.
2. **Icons are substitutes.** Lucide stands in for an unknown icon set.
3. **The palette beyond `#2b7fc4` is proposed**, derived from the logo blue per the "simple, light colors" note.
4. **Both UI kits are constructions, not recreations.** No product screens were available to copy.
5. **No dark mode, no photography, no illustration, no slide template** — none were supplied, so none were invented.
