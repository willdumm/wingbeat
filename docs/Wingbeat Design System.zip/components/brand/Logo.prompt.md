The Wingbeat lockup: the two-arc wingbeat mark plus the wordmark in Manrope ExtraBold.

```jsx
<Logo size={28} />
<Logo size={22} tone="mono-white" />
<Logo size={32} showWordmark={false} />
```

Mark geometry is copied from the supplied `logo_plain.svg` — never redraw it. Clear space is at least the mark's height on all sides. On photography or the live map, use `mono-white` over a scrim, never the brand tone.
