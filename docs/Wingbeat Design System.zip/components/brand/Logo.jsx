import React from "react";

/* Wingbeat mark — path data copied verbatim from the supplied logo_plain.svg.
   Do not redraw or alter the geometry. `tone` only swaps fills. */
export function Logo({ size = 28, tone = "brand", showWordmark = true, className = "", style }) {
  const left = tone === "brand" ? "#0F1A24" : tone === "mono-white" ? "#FFFFFF" : tone === "mono-blue" ? "#2B7FC4" : "#0F1A24";
  const right = tone === "mono-white" ? "#FFFFFF" : tone === "mono-ink" ? "#0F1A24" : "#2B7FC4";
  const word = tone === "mono-white" ? "#FFFFFF" : tone === "mono-blue" ? "#2B7FC4" : "#0F1A24";
  return (
    <span className={className} style={{ display: "inline-flex", alignItems: "center", gap: size * 0.36, ...style }}>
      <svg width={size * 3} height={size} viewBox="0 0 120 40" aria-label="Wingbeat" role="img" style={{ flex: "none" }}>
        <g transform="translate(-27.312951,-84.004801)">
          <path fill={left} d="m 55.807629,87.878064 c -1.447577,-0.06761 -2.896794,-0.05688 -4.341337,0.03152 -5.778171,0.353617 -11.480183,1.953247 -16.691488,4.771285 a 4.8825002,4.8825002 0 0 0 -1.972489,6.617167 4.8825002,4.8825002 0 0 0 6.617167,1.970944 c 7.899494,-4.271694 17.271108,-4.844926 25.632544,-1.568384 6.71532,2.631494 12.221554,7.528294 15.628503,13.758334 1.290447,-3.54672 3.031618,-6.87294 5.157308,-9.90947 C 81.426376,97.815 75.499193,93.306468 68.614599,90.608646 64.477562,88.987492 60.150358,88.080881 55.807629,87.878064 Z" />
          <path fill={right} d="M 123.36653,87.909525 C 117.58836,87.555909 111.73414,88.447206 106.2181,90.608744 95.185998,94.93182 86.612893,103.90377 82.79427,115.12047 a 4.8825002,4.8825002 0 0 0 3.048828,6.19531 4.8825002,4.8825002 0 0 0 6.195313,-3.04883 c 2.894207,-8.50135 9.380749,-15.28987 17.742189,-18.566409 8.36143,-3.276542 17.73331,-2.70333 25.63281,1.568359 a 4.8825002,4.8825002 0 0 0 6.61719,-1.970703 4.8825002,4.8825002 0 0 0 -1.97266,-6.617188 c -5.2113,-2.818038 -10.91324,-4.417867 -16.69141,-4.771484 z" />
        </g>
      </svg>
      {showWordmark ? (
        <span style={{
          fontFamily: "var(--font-display)", fontWeight: "var(--weight-extrabold)",
          fontSize: size * 0.82, letterSpacing: "var(--tracking-display)", color: word, lineHeight: 1
        }}>Wingbeat</span>
      ) : null}
    </span>
  );
}
