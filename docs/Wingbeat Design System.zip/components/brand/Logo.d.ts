/**
 * @startingPoint section="Brand" subtitle="Wingbeat lockup and mark tones" viewport="700x180"
 */
export interface LogoProps {
  /** Mark height in px; the wordmark scales from it. @default 28 */
  size?: number;
  /** brand = ink left wing + sky right wing (default). Mono tones for single-colour grounds. */
  tone?: "brand" | "mono-ink" | "mono-white" | "mono-blue";
  /** Set false for the mark alone (app icon, favicon, tight nav). @default true */
  showWordmark?: boolean;
  className?: string;
  style?: React.CSSProperties;
}
export declare function Logo(props: LogoProps): JSX.Element;
