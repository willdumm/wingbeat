import React from "react";

export function Badge({ children, tone = "neutral", dot = false, count = false, className = "", ...rest }) {
  const cls = ["wb-badge", count ? "wb-badge--count" : `wb-badge--${tone}`, dot && "wb-badge--dot", className]
    .filter(Boolean).join(" ");
  return <span className={cls} {...rest}>{children}</span>;
}
