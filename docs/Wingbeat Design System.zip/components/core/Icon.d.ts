export interface IconProps {
  /** Lucide icon name in kebab-case, e.g. "plane-takeoff". */
  name: string;
  /** Pixel box; use 16 / 20 / 24 (--icon-sm/md/lg). @default 20 */
  size?: number;
  /** Lucide stroke width. Wingbeat uses 2 everywhere. @default 2 */
  strokeWidth?: number;
  /** @default "currentColor" */
  color?: string;
  className?: string;
  style?: React.CSSProperties;
}
export declare function Icon(props: IconProps): JSX.Element;
