A square, label-less control for toolbars, map overlays and card corners.

```jsx
<IconButton icon="bell" label="Alerts" />
<IconButton icon="layers" label="Map layers" variant="glass" />
<IconButton icon="plus" label="Add flight" variant="solid" size="lg" />
```

`variant="glass"` is reserved for controls sitting on top of the live map. Always pass `label`; it doubles as the tooltip.
