import React from "react";
import { Icon } from "./Icon.jsx";

export function Tag({ children, icon, selected = false, onClick, onRemove, className = "", ...rest }) {
  const interactive = Boolean(onClick);
  const cls = ["wb-tag", interactive && "wb-tag--interactive", selected && "wb-tag--selected", className]
    .filter(Boolean).join(" ");
  const El = interactive ? "button" : "span";
  return (
    <El className={cls} type={interactive ? "button" : undefined} onClick={onClick}
        aria-pressed={interactive ? selected : undefined} {...rest}>
      {icon ? <Icon name={icon} size={14} /> : null}
      {children}
      {onRemove ? (
        <span className="wb-tag__x" role="button" aria-label="Remove"
              onClick={(e) => { e.stopPropagation(); onRemove(e); }}>
          <Icon name="x" size={12} />
        </span>
      ) : null}
    </El>
  );
}
