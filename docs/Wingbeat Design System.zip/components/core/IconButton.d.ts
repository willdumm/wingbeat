export interface IconButtonProps {
  /** Lucide icon name. */
  icon: string;
  /** Required accessible label — also the tooltip. */
  label: string;
  /** glass = frosted, for controls floating over the live map only. */
  variant?: "quiet" | "outline" | "solid" | "glass";
  size?: "sm" | "md" | "lg";
  disabled?: boolean;
  onClick?: (e: React.MouseEvent) => void;
  className?: string;
}
export declare function IconButton(props: IconButtonProps): JSX.Element;
