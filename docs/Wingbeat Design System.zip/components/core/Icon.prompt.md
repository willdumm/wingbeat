Wingbeat's icon wrapper — renders a Lucide glyph at brand stroke weight; use it anywhere an icon is needed instead of inline SVG.

```jsx
<Icon name="plane-takeoff" size={20} />
<Icon name="bell" size={16} color="var(--text-muted)" />
```

Requires the Lucide UMD script on the page (`https://unpkg.com/lucide@0.454.0/dist/umd/lucide.js`). Sizes: 16 (inline with text), 20 (default, controls), 24 (nav). Stroke width is always 2 — do not thin it.
