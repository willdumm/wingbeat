export interface TagProps {
  children?: React.ReactNode;
  /** Lucide icon name, rendered at 14px before the label. */
  icon?: string;
  selected?: boolean;
  /** Makes the tag a toggle button. */
  onClick?: (e: React.MouseEvent) => void;
  /** Adds a remove affordance. */
  onRemove?: (e: React.MouseEvent) => void;
  className?: string;
}
export declare function Tag(props: TagProps): JSX.Element;
