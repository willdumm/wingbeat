/**
 * Wingbeat's primary action control.
 * @startingPoint section="Core" subtitle="Buttons, icon buttons, badges and tags" viewport="700x200"
 */
export interface ButtonProps {
  children?: React.ReactNode;
  /** primary = sky-500 fill (one per view). accent = dusk-500, marketing CTAs only. inverse = white on dark/brand grounds. */
  variant?: "primary" | "secondary" | "ghost" | "accent" | "inverse" | "danger";
  /** sm 32px / md 40px / lg 48px. Touch surfaces use md or lg. @default "md" */
  size?: "sm" | "md" | "lg";
  /** Lucide icon name rendered before the label. */
  icon?: string;
  /** Lucide icon name rendered after the label. */
  iconAfter?: string;
  fullWidth?: boolean;
  disabled?: boolean;
  /** Renders an <a> instead of a <button>. */
  href?: string;
  type?: "button" | "submit" | "reset";
  onClick?: (e: React.MouseEvent) => void;
  className?: string;
}
export declare function Button(props: ButtonProps): JSX.Element;
