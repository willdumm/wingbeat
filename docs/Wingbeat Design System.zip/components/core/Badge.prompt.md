A small, read-only label for metadata and counts.

```jsx
<Badge tone="brand">Gate B12</Badge>
<Badge tone="ontime" dot>On time</Badge>
<Badge count>3</Badge>
```

For live flight state use `FlightStatusBadge` instead — it owns the uppercase status vocabulary and the pulsing live dot.
