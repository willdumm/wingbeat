import React from "react";

/* Renders a Lucide icon. Requires the Lucide UMD script on the page:
   <script src="https://unpkg.com/lucide@0.454.0/dist/umd/lucide.js"></script>
   Wingbeat does not ship its own glyph set; Lucide at 2px stroke is the house icon system. */
export function Icon({ name, size = 20, strokeWidth = 2, color = "currentColor", className = "", style }) {
  const host = React.useRef(null);
  React.useEffect(() => {
    const el = host.current;
    if (!el || !window.lucide) return;
    el.innerHTML = "";
    const span = document.createElement("i");
    span.setAttribute("data-lucide", name);
    el.appendChild(span);
    try {
      window.lucide.createIcons({
        root: el,
        attrs: { width: size, height: size, "stroke-width": strokeWidth, stroke: color }
      });
    } catch (e) { /* icon set not ready */ }
  }, [name, size, strokeWidth, color]);
  return (
    <span
      ref={host}
      aria-hidden="true"
      className={className}
      style={{ display: "inline-flex", width: size, height: size, flex: "none", color, ...style }}
    />
  );
}
