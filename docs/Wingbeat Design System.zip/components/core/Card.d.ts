export interface CardProps {
  children?: React.ReactNode;
  /** flat = hairline only, default = shadow-sm, raised = shadow-md with no border. */
  elevation?: "flat" | "default" | "raised";
  /** md = 20px (--pad-card), lg = 24px, none for edge-to-edge content like lists and maps. */
  padding?: "none" | "md" | "lg";
  /** Adds hover lift + press settle; also implied by onClick. */
  interactive?: boolean;
  onClick?: (e: React.MouseEvent) => void;
  /** Override the element ("div" default, "button" when clickable). */
  as?: string;
  className?: string;
}
export declare function Card(props: CardProps): JSX.Element;

export interface CardHeaderProps {
  title: React.ReactNode;
  /** Right-aligned slot — usually an IconButton or ghost Button. */
  action?: React.ReactNode;
  className?: string;
}
export declare function CardHeader(props: CardHeaderProps): JSX.Element;
