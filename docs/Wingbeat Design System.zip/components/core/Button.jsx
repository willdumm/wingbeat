import React from "react";
import { Icon } from "./Icon.jsx";

/**
 * @startingPoint section="Core" subtitle="Buttons, icon buttons, badges and tags" viewport="700x200"
 */
export function Button({
  children, variant = "primary", size = "md", icon, iconAfter, fullWidth = false,
  disabled = false, href, type = "button", onClick, className = "", ...rest
}) {
  const cls = ["wb-btn", `wb-btn--${variant}`, `wb-btn--${size}`, fullWidth && "wb-btn--full", className]
    .filter(Boolean).join(" ");
  const iconSize = size === "lg" ? 20 : size === "sm" ? 16 : 18;
  const inner = (
    <>
      {icon ? <Icon name={icon} size={iconSize} /> : null}
      {children}
      {iconAfter ? <Icon name={iconAfter} size={iconSize} /> : null}
    </>
  );
  if (href && !disabled) return <a className={cls} href={href} onClick={onClick} {...rest}>{inner}</a>;
  return <button className={cls} type={type} disabled={disabled} onClick={onClick} {...rest}>{inner}</button>;
}
