The standard Wingbeat action control — labelled, 40px tall by default, sky-blue when it is the one thing to do on the screen.

```jsx
<Button variant="primary" icon="search">Track flight</Button>
<Button variant="secondary" size="sm">Share</Button>
<Button variant="ghost" iconAfter="arrow-right">All flights</Button>
```

Variants: `primary` (sky-500 — at most one per view), `secondary` (white + hairline), `ghost` (text-only, sky), `accent` (dusk orange, marketing CTAs only), `inverse` (white on brand/dark ground), `danger`. Sizes `sm|md|lg` = 32/40/48px. Labels are sentence-case verb phrases ("Track flight", not "TRACK FLIGHT" or "Submit").
