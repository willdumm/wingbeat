import React from "react";
import { Icon } from "./Icon.jsx";

export function IconButton({
  icon, label, variant = "quiet", size = "md", disabled = false, onClick, className = "", ...rest
}) {
  const cls = ["wb-iconbtn", `wb-iconbtn--${variant}`, `wb-iconbtn--${size}`, className].filter(Boolean).join(" ");
  const iconSize = size === "lg" ? 22 : size === "sm" ? 16 : 20;
  return (
    <button className={cls} type="button" aria-label={label} title={label} disabled={disabled} onClick={onClick} {...rest}>
      <Icon name={icon} size={iconSize} />
    </button>
  );
}
