A 6px-radius chip used for filters and user-applied labels — squarer than Badge, and usually interactive.

```jsx
<Tag icon="filter" onClick={toggle} selected>Departures</Tag>
<Tag onRemove={() => drop("LHR")}>LHR</Tag>
```

Tags filter; Badges describe. Don't use Tag for flight status.
