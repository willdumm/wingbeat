export interface BadgeProps {
  children?: React.ReactNode;
  tone?: "neutral" | "brand" | "accent" | "ontime" | "delayed" | "cancelled" | "solid";
  /** Prefix a 6px dot in the current colour. */
  dot?: boolean;
  /** Render as a compact numeric counter (dusk fill) — ignores `tone`. */
  count?: boolean;
  className?: string;
}
export declare function Badge(props: BadgeProps): JSX.Element;
