The surface everything sits on: white, 14px radius, hairline border plus a short cool shadow.

```jsx
<Card padding="none">
  <CardHeader title="Watchlist" action={<Button variant="ghost" size="sm">Edit</Button>} />
  <div style={{ padding: "var(--pad-card)" }}>…</div>
</Card>
<Card interactive onClick={open}>…</Card>
```

Interactive cards lift 2px on hover and settle back on press. Use `padding="none"` when the card holds a list or a map so rows can run edge to edge.
