import React from "react";

export function Card({
  children, elevation = "default", padding = "md", interactive = false,
  onClick, as, className = "", ...rest
}) {
  const padCls = padding === "none" ? "wb-card--pad-none" : padding === "lg" ? "wb-card--pad-lg" : "wb-card--pad";
  const cls = ["wb-card", elevation !== "default" && `wb-card--${elevation}`, padCls,
    (interactive || onClick) && "wb-card--interactive", className].filter(Boolean).join(" ");
  const El = as || ((interactive || onClick) ? "button" : "div");
  return <El className={cls} type={El === "button" ? "button" : undefined} onClick={onClick} {...rest}>{children}</El>;
}

export function CardHeader({ title, action, className = "" }) {
  return (
    <div className={["wb-card__header", className].filter(Boolean).join(" ")}>
      <span className="wb-card__title">{title}</span>
      {action}
    </div>
  );
}
