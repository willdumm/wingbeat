import React from "react";

export function Tooltip({ label, placement = "top", children, className = "" }) {
  return (
    <span className={["wb-tip", className].filter(Boolean).join(" ")} tabIndex={0}>
      {children}
      <span className={`wb-tip__bubble wb-tip__bubble--${placement}`} role="tooltip">{label}</span>
    </span>
  );
}
