Names a control or expands an abbreviation on hover and focus. Ink bubble, 12px semibold, no arrow.

```jsx
<Tooltip label="Ground speed"><Icon name="gauge" /></Tooltip>
```

Web only — never the sole carrier of information on touch surfaces. Keep to three or four words.
