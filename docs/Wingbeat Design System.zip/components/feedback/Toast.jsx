import React from "react";

export function Toast({ title, message, tone = "info", actionLabel, onAction, className = "" }) {
  const cls = ["wb-toast", `wb-toast--${tone}`, className].filter(Boolean).join(" ");
  return (
    <div className={cls} role="status">
      <span className="wb-toast__dot" />
      <div style={{ minWidth: 0 }}>
        <div className="wb-toast__title">{title}</div>
        {message ? <div className="wb-toast__msg">{message}</div> : null}
      </div>
      {actionLabel ? <button className="wb-toast__action" type="button" onClick={onAction}>{actionLabel}</button> : null}
    </div>
  );
}
