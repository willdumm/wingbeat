A dark, self-dismissing notice — Wingbeat's flight-alert surface.

```jsx
<Toast tone="delayed" title="BA117 now 22 min late"
       message="New departure 14:52 · Gate B12" actionLabel="View" onAction={open} />
```

Titles state the change, not the app's action ("BA117 now 22 min late", never "Alert sent"). One action maximum. Stack bottom-centre on mobile, bottom-right on web, 12px apart.
