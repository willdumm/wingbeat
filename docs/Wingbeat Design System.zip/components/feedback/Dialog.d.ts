export interface DialogProps {
  open?: boolean;
  title?: React.ReactNode;
  children?: React.ReactNode;
  /** Right-aligned action row on an ink-50 footer — secondary then primary. */
  footer?: React.ReactNode;
  /** Shows the close button and closes on scrim click. */
  onClose?: () => void;
  /** Max width in px. @default 440 */
  width?: number;
}
export declare function Dialog(props: DialogProps): JSX.Element | null;
