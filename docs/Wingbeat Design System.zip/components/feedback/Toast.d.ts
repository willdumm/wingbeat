export interface ToastProps {
  title: React.ReactNode;
  message?: React.ReactNode;
  /** Colours the leading dot. */
  tone?: "info" | "ontime" | "delayed" | "cancelled";
  /** Adds one sky-300 text action on the right. */
  actionLabel?: string;
  onAction?: () => void;
  className?: string;
}
export declare function Toast(props: ToastProps): JSX.Element;
