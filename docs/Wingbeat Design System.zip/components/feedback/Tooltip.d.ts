export interface TooltipProps {
  /** Short, no full stop. */
  label: React.ReactNode;
  placement?: "top" | "bottom" | "right";
  children?: React.ReactNode;
  className?: string;
}
export declare function Tooltip(props: TooltipProps): JSX.Element;
