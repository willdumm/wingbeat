import React from "react";
import { IconButton } from "../core/IconButton.jsx";

export function Dialog({ open = true, title, children, footer, onClose, width = 440 }) {
  if (!open) return null;
  return (
    <div className="wb-dialog__scrim" onClick={onClose} role="presentation">
      <div className="wb-dialog" style={{ maxWidth: width }} role="dialog" aria-modal="true"
           onClick={(e) => e.stopPropagation()}>
        <div className="wb-dialog__head">
          <span className="wb-dialog__title">{title}</span>
          {onClose ? <IconButton icon="x" label="Close" size="sm" onClick={onClose} /> : null}
        </div>
        <div className="wb-dialog__body">{children}</div>
        {footer ? <div className="wb-dialog__foot">{footer}</div> : null}
      </div>
    </div>
  );
}
