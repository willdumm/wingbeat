A centred modal for a single decision. Scrim is ink at 42%; the panel rises 8px on open.

```jsx
<Dialog open={open} title="Stop tracking BA117?" onClose={close}
  footer={<><Button variant="secondary" onClick={close}>Keep tracking</Button>
            <Button variant="danger" onClick={remove}>Stop tracking</Button></>}>
  You'll no longer get gate or delay alerts for this flight.
</Dialog>
```

The scrim is absolutely positioned, so give the containing element `position: relative` (or mount at the app root).
