import React from "react";

export function Radio({ checked, onChange, label, name, value, disabled = false, className = "", ...rest }) {
  const cls = ["wb-check", "wb-check--radio", disabled && "wb-check--disabled", className].filter(Boolean).join(" ");
  return (
    <label className={cls} style={{ position: "relative" }}>
      <input type="radio" name={name} value={value} checked={checked} onChange={onChange} disabled={disabled} {...rest} />
      <span className="wb-check__box">{checked ? <span className="wb-check__radiodot" /> : null}</span>
      {label ? <span>{label}</span> : null}
    </label>
  );
}
