Single-line text entry. `Field` wraps any control with a label, hint and error.

```jsx
<Field label="Flight number" hint="Airline code plus number, e.g. BA117">
  <Input mono icon="plane" placeholder="BA117" value={v} onChange={e => set(e.target.value)} />
</Field>
```

Set `mono` for flight numbers, airport codes and registrations — the brand always sets identifiers in IBM Plex Mono, uppercase. `size="lg"` for the search hero on marketing and mobile.
