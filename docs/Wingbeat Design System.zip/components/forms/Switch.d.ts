export interface SwitchProps {
  checked?: boolean;
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
  /** Placed after the track. In settings rows the label usually sits on the left instead — omit it and lay out the row yourself. */
  label?: React.ReactNode;
  disabled?: boolean;
  className?: string;
}
export declare function Switch(props: SwitchProps): JSX.Element;
