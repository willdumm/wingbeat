export interface SelectOption { value: string; label: string }
export interface SelectProps {
  value?: string;
  onChange?: (e: React.ChangeEvent<HTMLSelectElement>) => void;
  /** Strings or {value,label} pairs. */
  options?: (string | SelectOption)[];
  /** Empty-value first option. */
  placeholder?: string;
  disabled?: boolean;
  id?: string;
  className?: string;
}
export declare function Select(props: SelectProps): JSX.Element;
