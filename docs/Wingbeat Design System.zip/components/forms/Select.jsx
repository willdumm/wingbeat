import React from "react";
import { Icon } from "../core/Icon.jsx";

export function Select({ value, onChange, options = [], placeholder, disabled = false, id, className = "", ...rest }) {
  return (
    <div className={["wb-select", className].filter(Boolean).join(" ")}>
      <select className="wb-select__el" id={id} value={value} onChange={onChange} disabled={disabled} {...rest}>
        {placeholder ? <option value="">{placeholder}</option> : null}
        {options.map((o) => {
          const opt = typeof o === "string" ? { value: o, label: o } : o;
          return <option key={opt.value} value={opt.value}>{opt.label}</option>;
        })}
      </select>
      <span className="wb-select__chev"><Icon name="chevron-down" size={16} /></span>
    </div>
  );
}
