One-of-many choice in a vertical list; circular box with a sky-500 dot.

```jsx
{["Push", "Email", "Both"].map(o => (
  <Radio key={o} name="channel" value={o} label={o} checked={ch === o} onChange={() => setCh(o)} />
))}
```

Three or more options in a settings list. Two options side by side belong in `Tabs variant="pill"`.
