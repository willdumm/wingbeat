A 40×24 track that takes effect immediately — no Save button.

```jsx
<Switch checked={push} onChange={() => setPush(!push)} label="Push alerts" />
```

Use for instant settings (alerts, map layers). If the change needs confirming, use `Checkbox` in a form instead.
