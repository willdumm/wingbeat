export interface RadioProps {
  checked?: boolean;
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
  label?: React.ReactNode;
  /** Shared group name. */
  name?: string;
  value?: string;
  disabled?: boolean;
  className?: string;
}
export declare function Radio(props: RadioProps): JSX.Element;
