import React from "react";
import { Icon } from "../core/Icon.jsx";

export function Checkbox({ checked, onChange, label, disabled = false, className = "", ...rest }) {
  const cls = ["wb-check", disabled && "wb-check--disabled", className].filter(Boolean).join(" ");
  return (
    <label className={cls} style={{ position: "relative" }}>
      <input type="checkbox" checked={checked} onChange={onChange} disabled={disabled} {...rest} />
      <span className="wb-check__box">{checked ? <Icon name="check" size={13} strokeWidth={3} /> : null}</span>
      {label ? <span>{label}</span> : null}
    </label>
  );
}
