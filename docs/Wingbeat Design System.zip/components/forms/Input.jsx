import React from "react";
import { Icon } from "../core/Icon.jsx";

export function Field({ label, hint, error, htmlFor, children, className = "" }) {
  return (
    <div className={["wb-field", className].filter(Boolean).join(" ")}>
      {label ? <label className="wb-field__label" htmlFor={htmlFor}>{label}</label> : null}
      {children}
      {error ? <span className="wb-field__error">{error}</span>
        : hint ? <span className="wb-field__hint">{hint}</span> : null}
    </div>
  );
}

export function Input({
  value, onChange, placeholder, icon, trailing, size = "md", mono = false,
  invalid = false, disabled = false, type = "text", id, className = "", ...rest
}) {
  const cls = ["wb-input", size === "lg" && "wb-input--lg", invalid && "wb-input--invalid",
    disabled && "wb-input--disabled", className].filter(Boolean).join(" ");
  return (
    <div className={cls}>
      {icon ? <span className="wb-input__affix"><Icon name={icon} size={18} /></span> : null}
      <input
        id={id} className={["wb-input__el", mono && "wb-input__el--mono"].filter(Boolean).join(" ")}
        type={type} value={value} onChange={onChange} placeholder={placeholder} disabled={disabled} {...rest}
      />
      {trailing ? <span className="wb-input__affix">{trailing}</span> : null}
    </div>
  );
}
