/**
 * @startingPoint section="Forms" subtitle="Inputs, selects, checkboxes, radios and switches" viewport="700x320"
 */
export interface InputProps {
  value?: string;
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
  placeholder?: string;
  /** Lucide icon name shown as a leading affix. */
  icon?: string;
  /** Trailing node — a unit, a clear IconButton, a Badge. */
  trailing?: React.ReactNode;
  /** md 40px / lg 48px (search heroes and mobile). @default "md" */
  size?: "md" | "lg";
  /** Monospace + uppercase — use for flight numbers and airport codes. */
  mono?: boolean;
  invalid?: boolean;
  disabled?: boolean;
  type?: string;
  id?: string;
  className?: string;
}
export declare function Input(props: InputProps): JSX.Element;

export interface FieldProps {
  label?: React.ReactNode;
  /** Shown under the control; hidden while `error` is set. */
  hint?: React.ReactNode;
  error?: React.ReactNode;
  htmlFor?: string;
  children?: React.ReactNode;
  className?: string;
}
export declare function Field(props: FieldProps): JSX.Element;
