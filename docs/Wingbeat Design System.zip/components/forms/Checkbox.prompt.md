An 18px square checkbox with a 4px radius; fills sky-500 when checked.

```jsx
<Checkbox checked={on} onChange={() => setOn(!on)} label="Also alert me on gate changes" />
```

Multi-select only. For a single on/off setting use `Switch`.
