import React from "react";

export function Switch({ checked, onChange, label, disabled = false, className = "", ...rest }) {
  const cls = ["wb-switch", disabled && "wb-switch--disabled", className].filter(Boolean).join(" ");
  return (
    <label className={cls} style={{ position: "relative" }}>
      <input type="checkbox" role="switch" checked={checked} onChange={onChange} disabled={disabled} {...rest} />
      <span className="wb-switch__track"><span className="wb-switch__knob" /></span>
      {label ? <span>{label}</span> : null}
    </label>
  );
}
