A native select styled to match Input, with a Lucide chevron.

```jsx
<Field label="Alert me when">
  <Select value={v} onChange={e => set(e.target.value)}
    options={[{value:"dep",label:"It departs"},{value:"delay",label:"It's delayed 15+ min"}]} />
</Field>
```

Use for 4+ mutually exclusive options. For 2–3 short options use `Tabs variant="pill"`.
