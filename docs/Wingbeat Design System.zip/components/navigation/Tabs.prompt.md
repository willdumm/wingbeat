Switches between sibling views. Two variants: an underline bar for page sections, a pill group for in-card filters.

```jsx
<Tabs value={tab} onChange={setTab}
  items={[{id:"live",label:"Live",icon:"radio"},{id:"watch",label:"Watchlist",count:3}]} />
<Tabs variant="pill" value={dir} onChange={setDir} items={["Departures","Arrivals"]} />
```

Labels are one or two words, sentence case. The active underline is a 2px sky-500 rule.
