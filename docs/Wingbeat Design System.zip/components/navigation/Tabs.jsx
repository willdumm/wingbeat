import React from "react";
import { Icon } from "../core/Icon.jsx";
import { Badge } from "../core/Badge.jsx";

export function Tabs({ items = [], value, onChange, variant = "underline", className = "" }) {
  const cls = ["wb-tabs", variant === "pill" && "wb-tabs--pill", className].filter(Boolean).join(" ");
  return (
    <div className={cls} role="tablist">
      {items.map((it) => {
        const t = typeof it === "string" ? { id: it, label: it } : it;
        const active = t.id === value;
        return (
          <button key={t.id} role="tab" aria-selected={active} type="button"
            className={["wb-tab", active && "wb-tab--active"].filter(Boolean).join(" ")}
            onClick={() => onChange && onChange(t.id)}>
            <span style={{ display: "inline-flex", alignItems: "center", gap: "var(--gap-inline)" }}>
              {t.icon ? <Icon name={t.icon} size={16} /> : null}
              {t.label}
              {t.count != null ? <Badge count>{t.count}</Badge> : null}
            </span>
          </button>
        );
      })}
    </div>
  );
}
