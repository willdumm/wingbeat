export interface TabItem {
  id: string;
  label: React.ReactNode;
  /** Lucide icon name at 16px. */
  icon?: string;
  /** Renders a dusk counter badge after the label. */
  count?: number;
}
/**
 * @startingPoint section="Navigation" subtitle="Underline and pill tab bars" viewport="700x140"
 */
export interface TabsProps {
  items?: (string | TabItem)[];
  /** Active item id. */
  value?: string;
  onChange?: (id: string) => void;
  /** underline = page-level sections. pill = compact in-card filters (2–4 short options). */
  variant?: "underline" | "pill";
  className?: string;
}
export declare function Tabs(props: TabsProps): JSX.Element;
