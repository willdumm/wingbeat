The watchlist unit: flight number, status chip, route bar and a four-stat footer. Composes Card, FlightStatusBadge, FlightProgress and Stat.

```jsx
<FlightCard onClick={open} onPin={pin} pinned flight={{
  number:"BA117", airline:"British Airways", origin:"LHR", destination:"JFK",
  originCity:"London Heathrow", destinationCity:"New York JFK", status:"live",
  statusDetail:"FL340", percent:62, middle:"2h 10m left",
  departs:"11:40", arrives:"14:50", gate:"B12", aircraft:"B772"
}} />
```

Pass at most four footer stats — drop `gate`/`aircraft` before letting the row wrap.
