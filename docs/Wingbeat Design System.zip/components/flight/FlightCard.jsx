import React from "react";
import { Card } from "../core/Card.jsx";
import { Icon } from "../core/Icon.jsx";
import { FlightStatusBadge } from "./FlightStatusBadge.jsx";
import { FlightProgress } from "./FlightProgress.jsx";
import { Stat } from "./Stat.jsx";

export function FlightCard({ flight, onClick, onPin, pinned = false, className = "" }) {
  const f = flight || {};
  return (
    <Card padding="none" interactive={Boolean(onClick)} onClick={onClick} className={className}>
      <div className="wb-fc">
        <div className="wb-fc__top">
          <span className="wb-fc__no">{f.number}</span>
          <span className="wb-fc__airline">{f.airline}</span>
          <span style={{ marginLeft: "auto", display: "inline-flex", alignItems: "center", gap: "var(--space-2)" }}>
            <FlightStatusBadge status={f.status} detail={f.statusDetail} />
            {onPin ? (
              <span role="button" aria-label={pinned ? "Unpin" : "Pin"} className="wb-iconbtn wb-iconbtn--sm"
                    onClick={(e) => { e.stopPropagation(); onPin(e); }}>
                <Icon name={pinned ? "bookmark-check" : "bookmark"} size={16}
                      color={pinned ? "var(--action-primary)" : "var(--text-subtle)"} />
              </span>
            ) : null}
          </span>
        </div>
        <FlightProgress
          origin={f.origin} destination={f.destination}
          originCity={f.originCity} destinationCity={f.destinationCity}
          percent={f.percent} middle={f.middle} showPlane={f.status === "live"}
        />
        <div className="wb-fc__meta">
          <Stat label="Departs" value={f.departs} size="sm" />
          <Stat label="Arrives" value={f.arrives} size="sm" />
          {f.gate ? <Stat label="Gate" value={f.gate} size="sm" /> : null}
          {f.aircraft ? <Stat label="Aircraft" value={f.aircraft} size="sm" /> : null}
        </div>
      </div>
    </Card>
  );
}
