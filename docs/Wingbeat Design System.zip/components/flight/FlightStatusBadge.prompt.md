The one component allowed to state flight state. Uppercase 12px bold in a tinted pill; `live` gets a pulsing dusk dot.

```jsx
<FlightStatusBadge status="live" detail="FL340" />
<FlightStatusBadge status="delayed" detail="22 min" />
```

Status vocabulary is fixed: In air, Scheduled, On time, Delayed, Cancelled, Landed. Never invent new words for state, and never colour status text outside these six tones.
