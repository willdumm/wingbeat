/**
 * @startingPoint section="Flight" subtitle="Status chips, route progress and flight rows" viewport="700x340"
 */
export interface FlightStatusBadgeProps {
  /** live pulses a dusk dot; ontime/delayed/cancelled/landed are flat. */
  status?: "live" | "scheduled" | "ontime" | "delayed" | "cancelled" | "landed";
  /** Appended after a middot, e.g. "22 min" or "Gate B12". */
  detail?: React.ReactNode;
  className?: string;
}
export declare function FlightStatusBadge(props: FlightStatusBadgeProps): JSX.Element;
