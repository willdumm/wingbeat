export interface Flight {
  /** e.g. "BA117" */
  number: string;
  airline?: string;
  origin: string;
  destination: string;
  originCity?: string;
  destinationCity?: string;
  status?: "live" | "scheduled" | "ontime" | "delayed" | "cancelled" | "landed";
  /** Detail appended to the status chip, e.g. "22 min". */
  statusDetail?: string;
  percent?: number;
  /** Centre caption on the route bar. */
  middle?: string;
  departs?: string;
  arrives?: string;
  gate?: string;
  aircraft?: string;
}
export interface FlightCardProps {
  flight: Flight;
  onClick?: (e: React.MouseEvent) => void;
  /** Shows the bookmark affordance. */
  onPin?: (e: React.MouseEvent) => void;
  pinned?: boolean;
  className?: string;
}
export declare function FlightCard(props: FlightCardProps): JSX.Element;
