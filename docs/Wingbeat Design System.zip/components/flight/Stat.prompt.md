A label-over-figure pair for telemetry: altitude, speed, times, distances.

```jsx
<Stat label="Altitude" value="34,000" unit="ft" />
<Stat label="Scheduled" value="11:40" size="lg" align="end" />
```

Figures are always mono and tabular so columns of numbers line up. Units are separate and muted — never baked into the value string.
