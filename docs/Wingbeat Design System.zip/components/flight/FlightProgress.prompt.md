The route bar: two airport codes, a 3px track, and a plane glyph at the current position.

```jsx
<FlightProgress origin="LHR" destination="JFK" originCity="London Heathrow"
  destinationCity="New York" percent={62} middle="2h 10m left" />
```

Used in flight cards, the detail sheet header and on the web board. Set `showPlane={false}` for flights that haven't left or have landed. The fill animates over 360ms — don't animate it on first paint of a list.
