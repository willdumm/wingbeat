import React from "react";
import { Icon } from "../core/Icon.jsx";

export function FlightProgress({
  origin, destination, originCity, destinationCity, percent = 0,
  middle, showPlane = true, className = ""
}) {
  const p = Math.max(0, Math.min(100, percent));
  return (
    <div className={["wb-prog", className].filter(Boolean).join(" ")}>
      <div className="wb-prog__ends">
        <div>
          <div className="wb-prog__code">{origin}</div>
          {originCity ? <div className="wb-prog__city">{originCity}</div> : null}
        </div>
        {middle ? <div className="wb-prog__mid">{middle}</div> : null}
        <div style={{ textAlign: "right" }}>
          <div className="wb-prog__code">{destination}</div>
          {destinationCity ? <div className="wb-prog__city">{destinationCity}</div> : null}
        </div>
      </div>
      <div className="wb-prog__track">
        <div className="wb-prog__fill" style={{ width: `${p}%` }} />
        {showPlane ? (
          <span className="wb-prog__plane" style={{ left: `${p}%` }}>
            <Icon name="plane" size={16} />
          </span>
        ) : null}
      </div>
    </div>
  );
}
