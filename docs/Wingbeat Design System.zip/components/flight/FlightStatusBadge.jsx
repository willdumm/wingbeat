import React from "react";

const LABELS = {
  live: "In air", scheduled: "Scheduled", ontime: "On time",
  delayed: "Delayed", cancelled: "Cancelled", landed: "Landed"
};

export function FlightStatusBadge({ status = "scheduled", detail, className = "" }) {
  const cls = ["wb-status", `wb-status--${status}`, className].filter(Boolean).join(" ");
  return (
    <span className={cls}>
      <span className="wb-status__dot" />
      {LABELS[status] || status}
      {detail ? <span style={{ fontWeight: "var(--weight-semibold)", opacity: 0.85 }}>· {detail}</span> : null}
    </span>
  );
}
