import React from "react";

export function Stat({ label, value, unit, size = "md", align = "start", className = "" }) {
  const cls = ["wb-stat", align === "end" && "wb-stat--align-end", className].filter(Boolean).join(" ");
  return (
    <div className={cls}>
      <span className="wb-stat__label">{label}</span>
      <span className={`wb-stat__value wb-stat__value--${size}`}>
        {value}{unit ? <span className="wb-stat__unit">{unit}</span> : null}
      </span>
    </div>
  );
}
