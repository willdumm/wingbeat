export interface FlightProgressProps {
  /** IATA code, e.g. "LHR". Rendered in mono. */
  origin: string;
  destination: string;
  originCity?: string;
  destinationCity?: string;
  /** 0–100 along the route. */
  percent?: number;
  /** Centre caption — duration or time remaining, e.g. "2h 10m left". */
  middle?: React.ReactNode;
  /** Plane glyph riding the fill. Turn off for scheduled or landed flights. @default true */
  showPlane?: boolean;
  className?: string;
}
export declare function FlightProgress(props: FlightProgressProps): JSX.Element;
