export interface StatProps {
  /** Overline caption, 11px bold uppercase. */
  label: React.ReactNode;
  /** The figure — always monospace, tabular. */
  value: React.ReactNode;
  /** Small trailing unit, e.g. "ft" or "kt". */
  unit?: React.ReactNode;
  size?: "sm" | "md" | "lg";
  align?: "start" | "end";
  className?: string;
}
export declare function Stat(props: StatProps): JSX.Element;
