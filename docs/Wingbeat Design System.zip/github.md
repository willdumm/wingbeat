# repo: willdumm/wingbeat

repo: willdumm/wingbeat
branch: main

## Last sync

date: 2026-09-16T18:08:07Z

### Updated in this project

- Rewrote the web UI kit as a single-page product showcase: hero, features, how it works, open source, hosting options, docs band.
- Replaced invented airline-tracking prose with the real product: Garmin inReach MapShare polling, automatic flight segmentation, reverse-geocoded endpoints, takeoff/landing/gap notifications.
- Hosting section now reflects the repo's dual licence — self-host under AGPL-3.0, managed hosting, commercial licence.
- Removed the departures-board section (`ui_kits/web/Board.jsx`), which had no counterpart in the product.

## Screen map

| Project screen | Repo files |
| --- | --- |
| `ui_kits/web/index.html` + `Site.jsx` + `Showcase.jsx` | `README.md`, `COMMERCIAL_LICENSE.md`, `user-docs/mapshare-instructions.md` |
| `ui_kits/mobile_app/` | not derived from the repo (constructed before the repo was associated) |
