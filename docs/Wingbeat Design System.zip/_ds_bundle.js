/* @ds-bundle: {"format":4,"namespace":"WingbeatDesignSystem_072965","components":[{"name":"Logo","sourcePath":"components/brand/Logo.jsx"},{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Card","sourcePath":"components/core/Card.jsx"},{"name":"CardHeader","sourcePath":"components/core/Card.jsx"},{"name":"Icon","sourcePath":"components/core/Icon.jsx"},{"name":"IconButton","sourcePath":"components/core/IconButton.jsx"},{"name":"Tag","sourcePath":"components/core/Tag.jsx"},{"name":"Dialog","sourcePath":"components/feedback/Dialog.jsx"},{"name":"Toast","sourcePath":"components/feedback/Toast.jsx"},{"name":"Tooltip","sourcePath":"components/feedback/Tooltip.jsx"},{"name":"FlightCard","sourcePath":"components/flight/FlightCard.jsx"},{"name":"FlightProgress","sourcePath":"components/flight/FlightProgress.jsx"},{"name":"FlightStatusBadge","sourcePath":"components/flight/FlightStatusBadge.jsx"},{"name":"Stat","sourcePath":"components/flight/Stat.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"Field","sourcePath":"components/forms/Input.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"Radio","sourcePath":"components/forms/Radio.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"Switch","sourcePath":"components/forms/Switch.jsx"},{"name":"Tabs","sourcePath":"components/navigation/Tabs.jsx"}],"sourceHashes":{"components/brand/Logo.jsx":"0a42e77638cc","components/core/Badge.jsx":"507b37e1264e","components/core/Button.jsx":"144e9cec037a","components/core/Card.jsx":"b198fce90f4b","components/core/Icon.jsx":"af348a33df2e","components/core/IconButton.jsx":"7263277fde95","components/core/Tag.jsx":"fb604874b908","components/feedback/Dialog.jsx":"7e0b9376ef27","components/feedback/Toast.jsx":"1fec248c46e0","components/feedback/Tooltip.jsx":"b3984147a628","components/flight/FlightCard.jsx":"0ff11a4bebc6","components/flight/FlightProgress.jsx":"a614ab8465d9","components/flight/FlightStatusBadge.jsx":"d68d3e1b8197","components/flight/Stat.jsx":"45990adf9e00","components/forms/Checkbox.jsx":"4db3858dc476","components/forms/Input.jsx":"3cf967453bd1","components/forms/Radio.jsx":"863448080e99","components/forms/Select.jsx":"8426356cccce","components/forms/Switch.jsx":"becec72c4ed1","components/navigation/Tabs.jsx":"553f24b5756a","ui_kits/mobile_app/App.jsx":"accf22c26da2","ui_kits/mobile_app/Chrome.jsx":"e7522c4749ac","ui_kits/mobile_app/Detail.jsx":"6ad2462a35b3","ui_kits/mobile_app/Screens.jsx":"a44ed0b53298","ui_kits/mobile_app/data.js":"e6ee358e18c0","ui_kits/mobile_app/ios-frame.jsx":"24642b887be3","ui_kits/web/Showcase.jsx":"bc2f6dc2b118","ui_kits/web/Site.jsx":"154e93c5bbcf"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.WingbeatDesignSystem_072965 = window.WingbeatDesignSystem_072965 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/brand/Logo.jsx
try { (() => {
/* Wingbeat mark — path data copied verbatim from the supplied logo_plain.svg.
   Do not redraw or alter the geometry. `tone` only swaps fills. */
function Logo({
  size = 28,
  tone = "brand",
  showWordmark = true,
  className = "",
  style
}) {
  const left = tone === "brand" ? "#0F1A24" : tone === "mono-white" ? "#FFFFFF" : tone === "mono-blue" ? "#2B7FC4" : "#0F1A24";
  const right = tone === "mono-white" ? "#FFFFFF" : tone === "mono-ink" ? "#0F1A24" : "#2B7FC4";
  const word = tone === "mono-white" ? "#FFFFFF" : tone === "mono-blue" ? "#2B7FC4" : "#0F1A24";
  return /*#__PURE__*/React.createElement("span", {
    className: className,
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: size * 0.36,
      ...style
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: size * 3,
    height: size,
    viewBox: "0 0 120 40",
    "aria-label": "Wingbeat",
    role: "img",
    style: {
      flex: "none"
    }
  }, /*#__PURE__*/React.createElement("g", {
    transform: "translate(-27.312951,-84.004801)"
  }, /*#__PURE__*/React.createElement("path", {
    fill: left,
    d: "m 55.807629,87.878064 c -1.447577,-0.06761 -2.896794,-0.05688 -4.341337,0.03152 -5.778171,0.353617 -11.480183,1.953247 -16.691488,4.771285 a 4.8825002,4.8825002 0 0 0 -1.972489,6.617167 4.8825002,4.8825002 0 0 0 6.617167,1.970944 c 7.899494,-4.271694 17.271108,-4.844926 25.632544,-1.568384 6.71532,2.631494 12.221554,7.528294 15.628503,13.758334 1.290447,-3.54672 3.031618,-6.87294 5.157308,-9.90947 C 81.426376,97.815 75.499193,93.306468 68.614599,90.608646 64.477562,88.987492 60.150358,88.080881 55.807629,87.878064 Z"
  }), /*#__PURE__*/React.createElement("path", {
    fill: right,
    d: "M 123.36653,87.909525 C 117.58836,87.555909 111.73414,88.447206 106.2181,90.608744 95.185998,94.93182 86.612893,103.90377 82.79427,115.12047 a 4.8825002,4.8825002 0 0 0 3.048828,6.19531 4.8825002,4.8825002 0 0 0 6.195313,-3.04883 c 2.894207,-8.50135 9.380749,-15.28987 17.742189,-18.566409 8.36143,-3.276542 17.73331,-2.70333 25.63281,1.568359 a 4.8825002,4.8825002 0 0 0 6.61719,-1.970703 4.8825002,4.8825002 0 0 0 -1.97266,-6.617188 c -5.2113,-2.818038 -10.91324,-4.417867 -16.69141,-4.771484 z"
  }))), showWordmark ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-display)",
      fontWeight: "var(--weight-extrabold)",
      fontSize: size * 0.82,
      letterSpacing: "var(--tracking-display)",
      color: word,
      lineHeight: 1
    }
  }, "Wingbeat") : null);
}
Object.assign(__ds_scope, { Logo });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brand/Logo.jsx", error: String((e && e.message) || e) }); }

// components/core/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Badge({
  children,
  tone = "neutral",
  dot = false,
  count = false,
  className = "",
  ...rest
}) {
  const cls = ["wb-badge", count ? "wb-badge--count" : `wb-badge--${tone}`, dot && "wb-badge--dot", className].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement("span", _extends({
    className: cls
  }, rest), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Card({
  children,
  elevation = "default",
  padding = "md",
  interactive = false,
  onClick,
  as,
  className = "",
  ...rest
}) {
  const padCls = padding === "none" ? "wb-card--pad-none" : padding === "lg" ? "wb-card--pad-lg" : "wb-card--pad";
  const cls = ["wb-card", elevation !== "default" && `wb-card--${elevation}`, padCls, (interactive || onClick) && "wb-card--interactive", className].filter(Boolean).join(" ");
  const El = as || (interactive || onClick ? "button" : "div");
  return /*#__PURE__*/React.createElement(El, _extends({
    className: cls,
    type: El === "button" ? "button" : undefined,
    onClick: onClick
  }, rest), children);
}
function CardHeader({
  title,
  action,
  className = ""
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: ["wb-card__header", className].filter(Boolean).join(" ")
  }, /*#__PURE__*/React.createElement("span", {
    className: "wb-card__title"
  }, title), action);
}
Object.assign(__ds_scope, { Card, CardHeader });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Card.jsx", error: String((e && e.message) || e) }); }

// components/core/Icon.jsx
try { (() => {
/* Renders a Lucide icon. Requires the Lucide UMD script on the page:
   <script src="https://unpkg.com/lucide@0.454.0/dist/umd/lucide.js"></script>
   Wingbeat does not ship its own glyph set; Lucide at 2px stroke is the house icon system. */
function Icon({
  name,
  size = 20,
  strokeWidth = 2,
  color = "currentColor",
  className = "",
  style
}) {
  const host = React.useRef(null);
  React.useEffect(() => {
    const el = host.current;
    if (!el || !window.lucide) return;
    el.innerHTML = "";
    const span = document.createElement("i");
    span.setAttribute("data-lucide", name);
    el.appendChild(span);
    try {
      window.lucide.createIcons({
        root: el,
        attrs: {
          width: size,
          height: size,
          "stroke-width": strokeWidth,
          stroke: color
        }
      });
    } catch (e) {/* icon set not ready */}
  }, [name, size, strokeWidth, color]);
  return /*#__PURE__*/React.createElement("span", {
    ref: host,
    "aria-hidden": "true",
    className: className,
    style: {
      display: "inline-flex",
      width: size,
      height: size,
      flex: "none",
      color,
      ...style
    }
  });
}
Object.assign(__ds_scope, { Icon });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Icon.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * @startingPoint section="Core" subtitle="Buttons, icon buttons, badges and tags" viewport="700x200"
 */
function Button({
  children,
  variant = "primary",
  size = "md",
  icon,
  iconAfter,
  fullWidth = false,
  disabled = false,
  href,
  type = "button",
  onClick,
  className = "",
  ...rest
}) {
  const cls = ["wb-btn", `wb-btn--${variant}`, `wb-btn--${size}`, fullWidth && "wb-btn--full", className].filter(Boolean).join(" ");
  const iconSize = size === "lg" ? 20 : size === "sm" ? 16 : 18;
  const inner = /*#__PURE__*/React.createElement(React.Fragment, null, icon ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: iconSize
  }) : null, children, iconAfter ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: iconAfter,
    size: iconSize
  }) : null);
  if (href && !disabled) return /*#__PURE__*/React.createElement("a", _extends({
    className: cls,
    href: href,
    onClick: onClick
  }, rest), inner);
  return /*#__PURE__*/React.createElement("button", _extends({
    className: cls,
    type: type,
    disabled: disabled,
    onClick: onClick
  }, rest), inner);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/IconButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function IconButton({
  icon,
  label,
  variant = "quiet",
  size = "md",
  disabled = false,
  onClick,
  className = "",
  ...rest
}) {
  const cls = ["wb-iconbtn", `wb-iconbtn--${variant}`, `wb-iconbtn--${size}`, className].filter(Boolean).join(" ");
  const iconSize = size === "lg" ? 22 : size === "sm" ? 16 : 20;
  return /*#__PURE__*/React.createElement("button", _extends({
    className: cls,
    type: "button",
    "aria-label": label,
    title: label,
    disabled: disabled,
    onClick: onClick
  }, rest), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: iconSize
  }));
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/core/Tag.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Tag({
  children,
  icon,
  selected = false,
  onClick,
  onRemove,
  className = "",
  ...rest
}) {
  const interactive = Boolean(onClick);
  const cls = ["wb-tag", interactive && "wb-tag--interactive", selected && "wb-tag--selected", className].filter(Boolean).join(" ");
  const El = interactive ? "button" : "span";
  return /*#__PURE__*/React.createElement(El, _extends({
    className: cls,
    type: interactive ? "button" : undefined,
    onClick: onClick,
    "aria-pressed": interactive ? selected : undefined
  }, rest), icon ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 14
  }) : null, children, onRemove ? /*#__PURE__*/React.createElement("span", {
    className: "wb-tag__x",
    role: "button",
    "aria-label": "Remove",
    onClick: e => {
      e.stopPropagation();
      onRemove(e);
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "x",
    size: 12
  })) : null);
}
Object.assign(__ds_scope, { Tag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Tag.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Dialog.jsx
try { (() => {
function Dialog({
  open = true,
  title,
  children,
  footer,
  onClose,
  width = 440
}) {
  if (!open) return null;
  return /*#__PURE__*/React.createElement("div", {
    className: "wb-dialog__scrim",
    onClick: onClose,
    role: "presentation"
  }, /*#__PURE__*/React.createElement("div", {
    className: "wb-dialog",
    style: {
      maxWidth: width
    },
    role: "dialog",
    "aria-modal": "true",
    onClick: e => e.stopPropagation()
  }, /*#__PURE__*/React.createElement("div", {
    className: "wb-dialog__head"
  }, /*#__PURE__*/React.createElement("span", {
    className: "wb-dialog__title"
  }, title), onClose ? /*#__PURE__*/React.createElement(__ds_scope.IconButton, {
    icon: "x",
    label: "Close",
    size: "sm",
    onClick: onClose
  }) : null), /*#__PURE__*/React.createElement("div", {
    className: "wb-dialog__body"
  }, children), footer ? /*#__PURE__*/React.createElement("div", {
    className: "wb-dialog__foot"
  }, footer) : null));
}
Object.assign(__ds_scope, { Dialog });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Dialog.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Toast.jsx
try { (() => {
function Toast({
  title,
  message,
  tone = "info",
  actionLabel,
  onAction,
  className = ""
}) {
  const cls = ["wb-toast", `wb-toast--${tone}`, className].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement("div", {
    className: cls,
    role: "status"
  }, /*#__PURE__*/React.createElement("span", {
    className: "wb-toast__dot"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "wb-toast__title"
  }, title), message ? /*#__PURE__*/React.createElement("div", {
    className: "wb-toast__msg"
  }, message) : null), actionLabel ? /*#__PURE__*/React.createElement("button", {
    className: "wb-toast__action",
    type: "button",
    onClick: onAction
  }, actionLabel) : null);
}
Object.assign(__ds_scope, { Toast });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Toast.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Tooltip.jsx
try { (() => {
function Tooltip({
  label,
  placement = "top",
  children,
  className = ""
}) {
  return /*#__PURE__*/React.createElement("span", {
    className: ["wb-tip", className].filter(Boolean).join(" "),
    tabIndex: 0
  }, children, /*#__PURE__*/React.createElement("span", {
    className: `wb-tip__bubble wb-tip__bubble--${placement}`,
    role: "tooltip"
  }, label));
}
Object.assign(__ds_scope, { Tooltip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Tooltip.jsx", error: String((e && e.message) || e) }); }

// components/flight/FlightProgress.jsx
try { (() => {
function FlightProgress({
  origin,
  destination,
  originCity,
  destinationCity,
  percent = 0,
  middle,
  showPlane = true,
  className = ""
}) {
  const p = Math.max(0, Math.min(100, percent));
  return /*#__PURE__*/React.createElement("div", {
    className: ["wb-prog", className].filter(Boolean).join(" ")
  }, /*#__PURE__*/React.createElement("div", {
    className: "wb-prog__ends"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "wb-prog__code"
  }, origin), originCity ? /*#__PURE__*/React.createElement("div", {
    className: "wb-prog__city"
  }, originCity) : null), middle ? /*#__PURE__*/React.createElement("div", {
    className: "wb-prog__mid"
  }, middle) : null, /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: "right"
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "wb-prog__code"
  }, destination), destinationCity ? /*#__PURE__*/React.createElement("div", {
    className: "wb-prog__city"
  }, destinationCity) : null)), /*#__PURE__*/React.createElement("div", {
    className: "wb-prog__track"
  }, /*#__PURE__*/React.createElement("div", {
    className: "wb-prog__fill",
    style: {
      width: `${p}%`
    }
  }), showPlane ? /*#__PURE__*/React.createElement("span", {
    className: "wb-prog__plane",
    style: {
      left: `${p}%`
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "plane",
    size: 16
  })) : null));
}
Object.assign(__ds_scope, { FlightProgress });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/flight/FlightProgress.jsx", error: String((e && e.message) || e) }); }

// components/flight/FlightStatusBadge.jsx
try { (() => {
const LABELS = {
  live: "In air",
  scheduled: "Scheduled",
  ontime: "On time",
  delayed: "Delayed",
  cancelled: "Cancelled",
  landed: "Landed"
};
function FlightStatusBadge({
  status = "scheduled",
  detail,
  className = ""
}) {
  const cls = ["wb-status", `wb-status--${status}`, className].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement("span", {
    className: cls
  }, /*#__PURE__*/React.createElement("span", {
    className: "wb-status__dot"
  }), LABELS[status] || status, detail ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: "var(--weight-semibold)",
      opacity: 0.85
    }
  }, "\xB7 ", detail) : null);
}
Object.assign(__ds_scope, { FlightStatusBadge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/flight/FlightStatusBadge.jsx", error: String((e && e.message) || e) }); }

// components/flight/Stat.jsx
try { (() => {
function Stat({
  label,
  value,
  unit,
  size = "md",
  align = "start",
  className = ""
}) {
  const cls = ["wb-stat", align === "end" && "wb-stat--align-end", className].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement("div", {
    className: cls
  }, /*#__PURE__*/React.createElement("span", {
    className: "wb-stat__label"
  }, label), /*#__PURE__*/React.createElement("span", {
    className: `wb-stat__value wb-stat__value--${size}`
  }, value, unit ? /*#__PURE__*/React.createElement("span", {
    className: "wb-stat__unit"
  }, unit) : null));
}
Object.assign(__ds_scope, { Stat });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/flight/Stat.jsx", error: String((e && e.message) || e) }); }

// components/flight/FlightCard.jsx
try { (() => {
function FlightCard({
  flight,
  onClick,
  onPin,
  pinned = false,
  className = ""
}) {
  const f = flight || {};
  return /*#__PURE__*/React.createElement(__ds_scope.Card, {
    padding: "none",
    interactive: Boolean(onClick),
    onClick: onClick,
    className: className
  }, /*#__PURE__*/React.createElement("div", {
    className: "wb-fc"
  }, /*#__PURE__*/React.createElement("div", {
    className: "wb-fc__top"
  }, /*#__PURE__*/React.createElement("span", {
    className: "wb-fc__no"
  }, f.number), /*#__PURE__*/React.createElement("span", {
    className: "wb-fc__airline"
  }, f.airline), /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: "auto",
      display: "inline-flex",
      alignItems: "center",
      gap: "var(--space-2)"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.FlightStatusBadge, {
    status: f.status,
    detail: f.statusDetail
  }), onPin ? /*#__PURE__*/React.createElement("span", {
    role: "button",
    "aria-label": pinned ? "Unpin" : "Pin",
    className: "wb-iconbtn wb-iconbtn--sm",
    onClick: e => {
      e.stopPropagation();
      onPin(e);
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: pinned ? "bookmark-check" : "bookmark",
    size: 16,
    color: pinned ? "var(--action-primary)" : "var(--text-subtle)"
  })) : null)), /*#__PURE__*/React.createElement(__ds_scope.FlightProgress, {
    origin: f.origin,
    destination: f.destination,
    originCity: f.originCity,
    destinationCity: f.destinationCity,
    percent: f.percent,
    middle: f.middle,
    showPlane: f.status === "live"
  }), /*#__PURE__*/React.createElement("div", {
    className: "wb-fc__meta"
  }, /*#__PURE__*/React.createElement(__ds_scope.Stat, {
    label: "Departs",
    value: f.departs,
    size: "sm"
  }), /*#__PURE__*/React.createElement(__ds_scope.Stat, {
    label: "Arrives",
    value: f.arrives,
    size: "sm"
  }), f.gate ? /*#__PURE__*/React.createElement(__ds_scope.Stat, {
    label: "Gate",
    value: f.gate,
    size: "sm"
  }) : null, f.aircraft ? /*#__PURE__*/React.createElement(__ds_scope.Stat, {
    label: "Aircraft",
    value: f.aircraft,
    size: "sm"
  }) : null)));
}
Object.assign(__ds_scope, { FlightCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/flight/FlightCard.jsx", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Checkbox({
  checked,
  onChange,
  label,
  disabled = false,
  className = "",
  ...rest
}) {
  const cls = ["wb-check", disabled && "wb-check--disabled", className].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement("label", {
    className: cls,
    style: {
      position: "relative"
    }
  }, /*#__PURE__*/React.createElement("input", _extends({
    type: "checkbox",
    checked: checked,
    onChange: onChange,
    disabled: disabled
  }, rest)), /*#__PURE__*/React.createElement("span", {
    className: "wb-check__box"
  }, checked ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "check",
    size: 13,
    strokeWidth: 3
  }) : null), label ? /*#__PURE__*/React.createElement("span", null, label) : null);
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Field({
  label,
  hint,
  error,
  htmlFor,
  children,
  className = ""
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: ["wb-field", className].filter(Boolean).join(" ")
  }, label ? /*#__PURE__*/React.createElement("label", {
    className: "wb-field__label",
    htmlFor: htmlFor
  }, label) : null, children, error ? /*#__PURE__*/React.createElement("span", {
    className: "wb-field__error"
  }, error) : hint ? /*#__PURE__*/React.createElement("span", {
    className: "wb-field__hint"
  }, hint) : null);
}
function Input({
  value,
  onChange,
  placeholder,
  icon,
  trailing,
  size = "md",
  mono = false,
  invalid = false,
  disabled = false,
  type = "text",
  id,
  className = "",
  ...rest
}) {
  const cls = ["wb-input", size === "lg" && "wb-input--lg", invalid && "wb-input--invalid", disabled && "wb-input--disabled", className].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement("div", {
    className: cls
  }, icon ? /*#__PURE__*/React.createElement("span", {
    className: "wb-input__affix"
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 18
  })) : null, /*#__PURE__*/React.createElement("input", _extends({
    id: id,
    className: ["wb-input__el", mono && "wb-input__el--mono"].filter(Boolean).join(" "),
    type: type,
    value: value,
    onChange: onChange,
    placeholder: placeholder,
    disabled: disabled
  }, rest)), trailing ? /*#__PURE__*/React.createElement("span", {
    className: "wb-input__affix"
  }, trailing) : null);
}
Object.assign(__ds_scope, { Field, Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/Radio.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Radio({
  checked,
  onChange,
  label,
  name,
  value,
  disabled = false,
  className = "",
  ...rest
}) {
  const cls = ["wb-check", "wb-check--radio", disabled && "wb-check--disabled", className].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement("label", {
    className: cls,
    style: {
      position: "relative"
    }
  }, /*#__PURE__*/React.createElement("input", _extends({
    type: "radio",
    name: name,
    value: value,
    checked: checked,
    onChange: onChange,
    disabled: disabled
  }, rest)), /*#__PURE__*/React.createElement("span", {
    className: "wb-check__box"
  }, checked ? /*#__PURE__*/React.createElement("span", {
    className: "wb-check__radiodot"
  }) : null), label ? /*#__PURE__*/React.createElement("span", null, label) : null);
}
Object.assign(__ds_scope, { Radio });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Radio.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Select({
  value,
  onChange,
  options = [],
  placeholder,
  disabled = false,
  id,
  className = "",
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: ["wb-select", className].filter(Boolean).join(" ")
  }, /*#__PURE__*/React.createElement("select", _extends({
    className: "wb-select__el",
    id: id,
    value: value,
    onChange: onChange,
    disabled: disabled
  }, rest), placeholder ? /*#__PURE__*/React.createElement("option", {
    value: ""
  }, placeholder) : null, options.map(o => {
    const opt = typeof o === "string" ? {
      value: o,
      label: o
    } : o;
    return /*#__PURE__*/React.createElement("option", {
      key: opt.value,
      value: opt.value
    }, opt.label);
  })), /*#__PURE__*/React.createElement("span", {
    className: "wb-select__chev"
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "chevron-down",
    size: 16
  })));
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/forms/Switch.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Switch({
  checked,
  onChange,
  label,
  disabled = false,
  className = "",
  ...rest
}) {
  const cls = ["wb-switch", disabled && "wb-switch--disabled", className].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement("label", {
    className: cls,
    style: {
      position: "relative"
    }
  }, /*#__PURE__*/React.createElement("input", _extends({
    type: "checkbox",
    role: "switch",
    checked: checked,
    onChange: onChange,
    disabled: disabled
  }, rest)), /*#__PURE__*/React.createElement("span", {
    className: "wb-switch__track"
  }, /*#__PURE__*/React.createElement("span", {
    className: "wb-switch__knob"
  })), label ? /*#__PURE__*/React.createElement("span", null, label) : null);
}
Object.assign(__ds_scope, { Switch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Switch.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Tabs.jsx
try { (() => {
function Tabs({
  items = [],
  value,
  onChange,
  variant = "underline",
  className = ""
}) {
  const cls = ["wb-tabs", variant === "pill" && "wb-tabs--pill", className].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement("div", {
    className: cls,
    role: "tablist"
  }, items.map(it => {
    const t = typeof it === "string" ? {
      id: it,
      label: it
    } : it;
    const active = t.id === value;
    return /*#__PURE__*/React.createElement("button", {
      key: t.id,
      role: "tab",
      "aria-selected": active,
      type: "button",
      className: ["wb-tab", active && "wb-tab--active"].filter(Boolean).join(" "),
      onClick: () => onChange && onChange(t.id)
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        display: "inline-flex",
        alignItems: "center",
        gap: "var(--gap-inline)"
      }
    }, t.icon ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
      name: t.icon,
      size: 16
    }) : null, t.label, t.count != null ? /*#__PURE__*/React.createElement(__ds_scope.Badge, {
      count: true
    }, t.count) : null));
  }));
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Tabs.jsx", error: String((e && e.message) || e) }); }

// ui_kits/mobile_app/App.jsx
try { (() => {
const {
  Toast
} = window.WingbeatDesignSystem_072965;
function App() {
  const [tab, setTab] = React.useState("live");
  const [detail, setDetail] = React.useState(null);
  const [toast, setToast] = React.useState(false);
  React.useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(false), 3200);
    return () => clearTimeout(t);
  }, [toast]);
  const open = id => setDetail(id);
  return /*#__PURE__*/React.createElement(IOSDevice, {
    width: 402,
    height: 874
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      overflow: "hidden",
      background: "var(--surface-page)",
      fontFamily: "var(--font-body)"
    }
  }, detail ? /*#__PURE__*/React.createElement(DetailScreen, {
    id: detail,
    onBack: () => setDetail(null),
    onToast: () => setToast(true)
  }) : /*#__PURE__*/React.createElement(React.Fragment, null, tab === "live" && /*#__PURE__*/React.createElement(LiveScreen, {
    onOpen: open,
    onSearch: () => setTab("watchlist")
  }), tab === "watchlist" && /*#__PURE__*/React.createElement(WatchlistScreen, {
    onOpen: open
  }), tab === "airports" && /*#__PURE__*/React.createElement(AirportsScreen, null), tab === "alerts" && /*#__PURE__*/React.createElement(AlertsScreen, null), /*#__PURE__*/React.createElement(TabBar, {
    value: tab,
    onChange: setTab
  })), toast ? /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: 16,
      right: 16,
      bottom: HOME_H + 16,
      zIndex: 80
    }
  }, /*#__PURE__*/React.createElement(Toast, {
    tone: "info",
    title: "Tracking BA117",
    message: "We'll alert you on gate and delay changes."
  })) : null));
}
Object.assign(window, {
  App
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/mobile_app/App.jsx", error: String((e && e.message) || e) }); }

// ui_kits/mobile_app/Chrome.jsx
try { (() => {
const {
  Icon,
  Logo,
  IconButton,
  Badge
} = window.WingbeatDesignSystem_072965;
const SB_H = 54,
  HOME_H = 34,
  TAB_H = 64;

/* Abstract map ground: graticule + great-circle arcs. The production app renders
   vector map tiles here; the kit stands in with the brand's map palette. */
function MapGround({
  children,
  height = "100%"
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      height,
      background: "var(--surface-map)",
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      backgroundImage: "linear-gradient(var(--sky-100) 1px,transparent 1px),linear-gradient(90deg,var(--sky-100) 1px,transparent 1px)",
      backgroundSize: "44px 44px"
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      inset: "-10% -20%",
      background: "radial-gradient(60% 45% at 30% 38%,var(--sky-100) 0%,rgba(230,241,250,0) 70%),radial-gradient(45% 40% at 78% 70%,var(--sky-100) 0%,rgba(230,241,250,0) 70%)"
    }
  }), /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 402 620",
    style: {
      position: "absolute",
      inset: 0,
      width: "100%",
      height: "100%"
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M46 430 C 120 250, 250 180, 372 152",
    fill: "none",
    stroke: "var(--sky-400)",
    strokeWidth: "2",
    strokeDasharray: "6 7",
    opacity: "0.85"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M46 430 C 96 340, 160 300, 214 272",
    fill: "none",
    stroke: "var(--sky-500)",
    strokeWidth: "2.5"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "46",
    cy: "430",
    r: "5",
    fill: "var(--white)",
    stroke: "var(--sky-600)",
    strokeWidth: "2.5"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "372",
    cy: "152",
    r: "5",
    fill: "var(--white)",
    stroke: "var(--sky-600)",
    strokeWidth: "2.5"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M120 560 C 200 520, 280 470, 360 470",
    fill: "none",
    stroke: "var(--ink-200)",
    strokeWidth: "2",
    strokeDasharray: "5 6"
  })), children);
}
function PlaneMarker({
  x,
  y,
  rotate = 0,
  active = false,
  label,
  onClick
}) {
  return /*#__PURE__*/React.createElement("button", {
    onClick: onClick,
    style: {
      position: "absolute",
      left: x,
      top: y,
      transform: "translate(-50%,-50%)",
      border: 0,
      background: "transparent",
      padding: 0,
      cursor: "pointer",
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      gap: 4
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: active ? 34 : 26,
      height: active ? 34 : 26,
      borderRadius: "var(--radius-full)",
      background: active ? "var(--dusk-500)" : "var(--surface-card)",
      boxShadow: active ? "var(--shadow-accent)" : "var(--shadow-sm)",
      border: active ? "none" : "1px solid var(--border-subtle)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      transform: `rotate(${rotate}deg)`,
      transition: "var(--transition-control)"
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "plane",
    size: active ? 18 : 14,
    color: active ? "#fff" : "var(--sky-600)"
  })), label ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: 10,
      fontWeight: 600,
      color: "var(--text-strong)",
      background: "var(--glass-bg)",
      backdropFilter: "var(--glass-blur)",
      padding: "2px 5px",
      borderRadius: 4,
      boxShadow: "var(--shadow-xs)"
    }
  }, label) : null);
}
function AppHeader({
  onSearch,
  query
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      paddingTop: SB_H,
      paddingLeft: "var(--pad-screen-x)",
      paddingRight: "var(--pad-screen-x)",
      paddingBottom: "var(--space-3)",
      background: "var(--glass-bg)",
      backdropFilter: "var(--glass-blur)",
      WebkitBackdropFilter: "var(--glass-blur)",
      borderBottom: "1px solid var(--border-subtle)",
      position: "relative",
      zIndex: 20
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      marginBottom: "var(--space-3)"
    }
  }, /*#__PURE__*/React.createElement(Logo, {
    size: 22
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 2,
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative",
      display: "inline-flex"
    }
  }, /*#__PURE__*/React.createElement(IconButton, {
    icon: "bell",
    label: "Alerts"
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      top: 4,
      right: 4
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    count: true
  }, "2"))), /*#__PURE__*/React.createElement(IconButton, {
    icon: "user-round",
    label: "Account"
  }))), /*#__PURE__*/React.createElement("div", {
    className: "wb-input",
    onClick: onSearch,
    style: {
      cursor: "text"
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "wb-input__affix"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "search",
    size: 18
  })), /*#__PURE__*/React.createElement("input", {
    className: "wb-input__el",
    placeholder: "Flight number, route or airport",
    value: query,
    readOnly: true
  })));
}
function TabBar({
  value,
  onChange
}) {
  const items = [{
    id: "live",
    label: "Live",
    icon: "radio"
  }, {
    id: "watchlist",
    label: "Watchlist",
    icon: "bookmark"
  }, {
    id: "airports",
    label: "Airports",
    icon: "building-2"
  }, {
    id: "alerts",
    label: "Alerts",
    icon: "bell"
  }];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: 0,
      right: 0,
      bottom: 0,
      height: TAB_H + HOME_H,
      paddingBottom: HOME_H,
      display: "flex",
      background: "var(--glass-bg)",
      backdropFilter: "var(--glass-blur)",
      WebkitBackdropFilter: "var(--glass-blur)",
      borderTop: "1px solid var(--border-subtle)",
      zIndex: 40
    }
  }, items.map(it => {
    const on = it.id === value;
    return /*#__PURE__*/React.createElement("button", {
      key: it.id,
      onClick: () => onChange(it.id),
      style: {
        flex: 1,
        border: 0,
        background: "transparent",
        cursor: "pointer",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        gap: 3,
        minHeight: "var(--tap-min)",
        color: on ? "var(--sky-600)" : "var(--text-subtle)"
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      name: it.icon,
      size: 22
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: "var(--font-ui)",
        fontSize: 11,
        fontWeight: on ? "var(--weight-bold)" : "var(--weight-medium)"
      }
    }, it.label));
  }));
}
function ScreenTitle({
  children,
  action
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "baseline",
      justifyContent: "space-between",
      padding: "var(--space-5) var(--pad-screen-x) var(--space-3)"
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontSize: "var(--size-2xl)",
      fontWeight: "var(--weight-bold)"
    }
  }, children), action);
}
Object.assign(window, {
  MapGround,
  PlaneMarker,
  AppHeader,
  TabBar,
  ScreenTitle,
  SB_H,
  HOME_H,
  TAB_H
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/mobile_app/Chrome.jsx", error: String((e && e.message) || e) }); }

// ui_kits/mobile_app/Detail.jsx
try { (() => {
const {
  Icon,
  IconButton,
  Card,
  Button,
  FlightStatusBadge,
  FlightProgress,
  Stat,
  Switch,
  Checkbox,
  Radio,
  Select,
  Field,
  Input,
  Tag,
  Badge,
  Dialog,
  Toast
} = window.WingbeatDesignSystem_072965;
function DetailScreen({
  id,
  onBack,
  onToast
}) {
  const f = FLIGHTS.find(x => x.id === id) || FLIGHTS[0];
  const [ask, setAsk] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      background: "var(--surface-page)",
      overflowY: "auto"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      height: 300,
      background: "var(--surface-map)"
    }
  }, /*#__PURE__*/React.createElement(MapGround, {
    height: "300px"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      top: SB_H,
      left: "var(--pad-screen-x)",
      right: "var(--pad-screen-x)",
      display: "flex",
      justifyContent: "space-between",
      zIndex: 5
    }
  }, /*#__PURE__*/React.createElement(IconButton, {
    icon: "arrow-left",
    label: "Back",
    variant: "glass",
    onClick: onBack
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: "var(--space-2)"
    }
  }, /*#__PURE__*/React.createElement(IconButton, {
    icon: "share-2",
    label: "Share",
    variant: "glass"
  }), /*#__PURE__*/React.createElement(IconButton, {
    icon: "bookmark-check",
    label: "Tracking",
    variant: "glass"
  }))), /*#__PURE__*/React.createElement(PlaneMarker, {
    x: 230,
    y: 190,
    rotate: -38,
    active: true
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: 0,
      right: 0,
      bottom: 0,
      height: 96,
      background: "var(--scrim-bottom)",
      display: "flex",
      alignItems: "flex-end",
      padding: "var(--space-4) var(--pad-screen-x)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      color: "#fff",
      fontSize: "var(--size-md)",
      fontWeight: 600,
      letterSpacing: "var(--tracking-wide)"
    }
  }, f.origin, " \u2192 ", f.destination, " \xB7 ", f.status === "live" ? `${f.statusDetail} · ${f.speed} kt` : "On the ground"))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "var(--space-5) var(--pad-screen-x)",
      display: "flex",
      flexDirection: "column",
      gap: "var(--space-4)",
      paddingBottom: HOME_H + 32
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "var(--space-3)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: "var(--size-xl)",
      fontWeight: 600,
      color: "var(--text-strong)"
    }
  }, f.number), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-body)",
      fontSize: "var(--size-sm)",
      color: "var(--text-muted)"
    }
  }, f.airline), /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: "auto"
    }
  }, /*#__PURE__*/React.createElement(FlightStatusBadge, {
    status: f.status,
    detail: f.statusDetail
  }))), /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement(FlightProgress, {
    origin: f.origin,
    destination: f.destination,
    originCity: f.originCity,
    destinationCity: f.destinationCity,
    percent: f.percent,
    middle: f.middle,
    showPlane: f.status === "live"
  })), /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr 1fr",
      gap: "var(--space-5) var(--space-4)"
    }
  }, /*#__PURE__*/React.createElement(Stat, {
    label: "Departs",
    value: f.departs
  }), /*#__PURE__*/React.createElement(Stat, {
    label: "Arrives",
    value: f.arrives
  }), /*#__PURE__*/React.createElement(Stat, {
    label: "Gate",
    value: f.gate
  }), /*#__PURE__*/React.createElement(Stat, {
    label: "Terminal",
    value: f.terminal
  }), /*#__PURE__*/React.createElement(Stat, {
    label: "Aircraft",
    value: f.aircraft
  }), /*#__PURE__*/React.createElement(Stat, {
    label: "Reg",
    value: f.registration
  }))), /*#__PURE__*/React.createElement(Card, {
    padding: "none"
  }, /*#__PURE__*/React.createElement("div", {
    className: "wb-card__header"
  }, /*#__PURE__*/React.createElement("span", {
    className: "wb-card__title"
  }, "Timeline"), /*#__PURE__*/React.createElement(Badge, {
    tone: "brand",
    dot: true
  }, "Updated 15s ago")), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "var(--pad-card)",
      display: "flex",
      flexDirection: "column",
      gap: "var(--space-4)"
    }
  }, f.timeline.map(([t, time, note], i) => /*#__PURE__*/React.createElement("div", {
    key: t,
    style: {
      display: "flex",
      gap: "var(--space-3)",
      alignItems: "flex-start"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 9,
      height: 9,
      marginTop: 6,
      borderRadius: "var(--radius-full)",
      flex: "none",
      background: i === 0 ? "var(--dusk-500)" : "var(--ink-200)"
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: "block",
      fontFamily: "var(--font-ui)",
      fontSize: "var(--size-md)",
      fontWeight: 600,
      color: "var(--text-strong)"
    }
  }, t), /*#__PURE__*/React.createElement("span", {
    style: {
      display: "block",
      fontFamily: "var(--font-body)",
      fontSize: "var(--size-xs)",
      color: "var(--text-muted)"
    }
  }, note)), /*#__PURE__*/React.createElement("span", {
    className: "wb-mono",
    style: {
      fontSize: "var(--size-md)",
      color: "var(--text-body)"
    }
  }, time))))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: "var(--space-3)"
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    icon: "bell",
    fullWidth: true,
    onClick: () => onToast()
  }, "Alert me"), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    icon: "bell-off",
    onClick: () => setAsk(true)
  }, "Stop"))), /*#__PURE__*/React.createElement(Dialog, {
    open: ask,
    title: `Stop tracking ${f.number}?`,
    onClose: () => setAsk(false),
    footer: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      variant: "secondary",
      onClick: () => setAsk(false)
    }, "Keep tracking"), /*#__PURE__*/React.createElement(Button, {
      variant: "danger",
      onClick: () => setAsk(false)
    }, "Stop tracking"))
  }, "You'll no longer get gate or delay alerts for this flight."));
}
function AlertsScreen() {
  const [push, setPush] = React.useState(true);
  const [gate, setGate] = React.useState(true);
  const [code, setCode] = React.useState(false);
  const [ch, setCh] = React.useState("Push");
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      overflowY: "auto",
      background: "var(--surface-page)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      paddingTop: SB_H
    }
  }), /*#__PURE__*/React.createElement(ScreenTitle, null, "Alerts"), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: `0 var(--pad-screen-x) ${TAB_H + HOME_H + 24}px`,
      display: "flex",
      flexDirection: "column",
      gap: "var(--space-4)"
    }
  }, /*#__PURE__*/React.createElement(Toast, {
    tone: "delayed",
    title: "LH431 now 22 min late",
    message: "New departure 13:27 \xB7 Gate A26",
    actionLabel: "View"
  }), /*#__PURE__*/React.createElement(Toast, {
    tone: "ontime",
    title: "AF1281 has landed",
    message: "Arrived 09:52 at BCN, 8 minutes early"
  }), /*#__PURE__*/React.createElement(Card, {
    padding: "none"
  }, /*#__PURE__*/React.createElement("div", {
    className: "wb-card__header"
  }, /*#__PURE__*/React.createElement("span", {
    className: "wb-card__title"
  }, "Notifications")), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "var(--pad-card)",
      display: "flex",
      flexDirection: "column",
      gap: "var(--space-5)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      gap: "var(--space-4)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-ui)",
      fontSize: "var(--size-md)",
      fontWeight: 600,
      color: "var(--text-strong)"
    }
  }, "Push alerts"), /*#__PURE__*/React.createElement(Switch, {
    checked: push,
    onChange: () => setPush(!push)
  })), /*#__PURE__*/React.createElement(Checkbox, {
    checked: gate,
    onChange: () => setGate(!gate),
    label: "Alert me on gate changes"
  }), /*#__PURE__*/React.createElement(Checkbox, {
    checked: code,
    onChange: () => setCode(!code),
    label: "Include codeshare flights"
  }), /*#__PURE__*/React.createElement(Field, {
    label: "Alert me when"
  }, /*#__PURE__*/React.createElement(Select, {
    value: "delay",
    options: [{
      value: "dep",
      label: "It departs"
    }, {
      value: "delay",
      label: "It's delayed 15+ min"
    }, {
      value: "gate",
      label: "The gate changes"
    }]
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("span", {
    className: "wb-overline",
    style: {
      display: "block",
      marginBottom: "var(--space-2)"
    }
  }, "Channel"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: "var(--space-5)"
    }
  }, ["Push", "Email", "Both"].map(o => /*#__PURE__*/React.createElement(Radio, {
    key: o,
    name: "ch",
    value: o,
    label: o,
    checked: ch === o,
    onChange: () => setCh(o)
  })))))), /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement("span", {
    className: "wb-overline",
    style: {
      display: "block",
      marginBottom: "var(--space-3)"
    }
  }, "Quiet hours"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: "var(--space-3)",
      alignItems: "flex-end"
    }
  }, /*#__PURE__*/React.createElement(Field, {
    label: "From",
    className: "wb-grow"
  }, /*#__PURE__*/React.createElement(Input, {
    mono: true,
    value: "23:00"
  })), /*#__PURE__*/React.createElement(Field, {
    label: "To"
  }, /*#__PURE__*/React.createElement(Input, {
    mono: true,
    value: "07:00"
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: "var(--space-2)",
      marginTop: "var(--space-4)",
      flexWrap: "wrap"
    }
  }, /*#__PURE__*/React.createElement(Tag, {
    icon: "moon",
    selected: true,
    onClick: () => {}
  }, "Overnight"), /*#__PURE__*/React.createElement(Tag, {
    onClick: () => {}
  }, "Weekends"), /*#__PURE__*/React.createElement(Tag, {
    onClick: () => {}
  }, "Never")))));
}
Object.assign(window, {
  DetailScreen,
  AlertsScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/mobile_app/Detail.jsx", error: String((e && e.message) || e) }); }

// ui_kits/mobile_app/Screens.jsx
try { (() => {
const {
  Icon,
  IconButton,
  Card,
  Button,
  FlightStatusBadge,
  FlightProgress,
  Stat,
  Tabs
} = window.WingbeatDesignSystem_072965;
function LiveScreen({
  onOpen,
  onSearch
}) {
  const [sel, setSel] = React.useState("BA117");
  const f = FLIGHTS.find(x => x.id === sel) || FLIGHTS[0];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0
    }
  }, /*#__PURE__*/React.createElement(MapGround, null), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      top: 0,
      left: 0,
      right: 0
    }
  }, /*#__PURE__*/React.createElement(AppHeader, {
    onSearch: onSearch,
    query: ""
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      top: 150,
      right: "var(--pad-screen-x)",
      display: "flex",
      flexDirection: "column",
      gap: "var(--space-2)",
      zIndex: 25
    }
  }, /*#__PURE__*/React.createElement(IconButton, {
    icon: "layers",
    label: "Map layers",
    variant: "glass"
  }), /*#__PURE__*/React.createElement(IconButton, {
    icon: "crosshair",
    label: "Centre on me",
    variant: "glass"
  }), /*#__PURE__*/React.createElement(IconButton, {
    icon: "cloud-sun",
    label: "Weather",
    variant: "glass"
  })), /*#__PURE__*/React.createElement(PlaneMarker, {
    x: 214,
    y: 330,
    rotate: -38,
    active: true,
    label: "BA117",
    onClick: () => setSel("BA117")
  }), /*#__PURE__*/React.createElement(PlaneMarker, {
    x: 108,
    y: 452,
    rotate: -12,
    onClick: () => setSel("AF1281")
  }), /*#__PURE__*/React.createElement(PlaneMarker, {
    x: 306,
    y: 252,
    rotate: -54,
    onClick: () => setSel("SQ317")
  }), /*#__PURE__*/React.createElement(PlaneMarker, {
    x: 168,
    y: 548,
    rotate: 22,
    onClick: () => setSel("LH431")
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: 0,
      right: 0,
      bottom: TAB_H + HOME_H,
      padding: "var(--space-3) var(--pad-screen-x) var(--space-4)",
      zIndex: 30
    }
  }, /*#__PURE__*/React.createElement(Card, {
    padding: "none",
    elevation: "raised",
    style: {
      borderRadius: "var(--radius-xl)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "var(--pad-card)",
      display: "flex",
      flexDirection: "column",
      gap: "var(--space-4)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "var(--space-3)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "wb-fc__no"
  }, f.number), /*#__PURE__*/React.createElement("span", {
    className: "wb-fc__airline"
  }, f.airline), /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: "auto"
    }
  }, /*#__PURE__*/React.createElement(FlightStatusBadge, {
    status: f.status,
    detail: f.statusDetail
  }))), /*#__PURE__*/React.createElement(FlightProgress, {
    origin: f.origin,
    destination: f.destination,
    originCity: f.originCity,
    destinationCity: f.destinationCity,
    percent: f.percent,
    middle: f.middle,
    showPlane: f.status === "live"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: "var(--space-6)",
      paddingTop: "var(--space-3)",
      borderTop: "1px solid var(--border-subtle)"
    }
  }, /*#__PURE__*/React.createElement(Stat, {
    label: "Altitude",
    value: f.altitude,
    unit: "ft",
    size: "sm"
  }), /*#__PURE__*/React.createElement(Stat, {
    label: "Speed",
    value: f.speed,
    unit: "kt",
    size: "sm"
  }), /*#__PURE__*/React.createElement(Stat, {
    label: "Gate",
    value: f.gate,
    size: "sm"
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: "auto"
    }
  }, /*#__PURE__*/React.createElement(Button, {
    size: "sm",
    variant: "ghost",
    iconAfter: "chevron-right",
    onClick: () => onOpen(f.id)
  }, "Details")))))));
}
function WatchlistScreen({
  onOpen
}) {
  const [tab, setTab] = React.useState("all");
  const list = tab === "all" ? FLIGHTS : FLIGHTS.filter(f => f.status === "live" || f.status === "delayed");
  const {
    FlightCard
  } = window.WingbeatDesignSystem_072965;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      overflowY: "auto",
      background: "var(--surface-page)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      paddingTop: SB_H
    }
  }), /*#__PURE__*/React.createElement(ScreenTitle, {
    action: /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      variant: "ghost",
      icon: "plus"
    }, "Add flight")
  }, "Watchlist"), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "0 var(--pad-screen-x) var(--space-4)"
    }
  }, /*#__PURE__*/React.createElement(Tabs, {
    variant: "pill",
    value: tab,
    onChange: setTab,
    items: [{
      id: "all",
      label: "All 4"
    }, {
      id: "today",
      label: "Active"
    }]
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "var(--space-4)",
      padding: `0 var(--pad-screen-x) ${TAB_H + HOME_H + 24}px`
    }
  }, list.map(f => /*#__PURE__*/React.createElement(FlightCard, {
    key: f.id,
    flight: f,
    pinned: true,
    onPin: () => {},
    onClick: () => onOpen(f.id)
  }))));
}
function AirportsScreen() {
  const rows = [["LHR", "London Heathrow", "1,284", "+4 min", "ontime"], ["JFK", "New York JFK", "976", "+11 min", "delayed"], ["FRA", "Frankfurt", "1,102", "On schedule", "ontime"], ["SIN", "Singapore Changi", "864", "+2 min", "ontime"], ["CDG", "Paris CDG", "1,031", "+18 min", "delayed"]];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      overflowY: "auto",
      background: "var(--surface-page)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      paddingTop: SB_H
    }
  }), /*#__PURE__*/React.createElement(ScreenTitle, null, "Airports"), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: `0 var(--pad-screen-x) ${TAB_H + HOME_H + 24}px`
    }
  }, /*#__PURE__*/React.createElement(Card, {
    padding: "none"
  }, rows.map(([code, name, count, delay, tone], i) => /*#__PURE__*/React.createElement("div", {
    key: code,
    style: {
      display: "flex",
      alignItems: "center",
      gap: "var(--space-4)",
      padding: "var(--space-4) var(--pad-card)",
      borderTop: i ? "1px solid var(--border-subtle)" : "none"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: "var(--size-md)",
      fontWeight: 600,
      color: "var(--sky-700)",
      background: "var(--surface-brand-soft)",
      borderRadius: "var(--radius-sm)",
      padding: "6px 8px",
      width: 52,
      textAlign: "center"
    }
  }, code), /*#__PURE__*/React.createElement("span", {
    style: {
      minWidth: 0,
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: "block",
      fontFamily: "var(--font-ui)",
      fontSize: "var(--size-md)",
      fontWeight: 600,
      color: "var(--text-strong)"
    }
  }, name), /*#__PURE__*/React.createElement("span", {
    style: {
      display: "block",
      fontFamily: "var(--font-body)",
      fontSize: "var(--size-xs)",
      color: "var(--text-muted)"
    }
  }, count, " flights today")), /*#__PURE__*/React.createElement(FlightStatusBadge, {
    status: tone,
    detail: delay.startsWith("+") ? delay : null
  }), /*#__PURE__*/React.createElement(Icon, {
    name: "chevron-right",
    size: 18,
    color: "var(--text-subtle)"
  }))))));
}
Object.assign(window, {
  LiveScreen,
  WatchlistScreen,
  AirportsScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/mobile_app/Screens.jsx", error: String((e && e.message) || e) }); }

// ui_kits/mobile_app/data.js
try { (() => {
const FLIGHTS = [{
  id: "BA117",
  number: "BA117",
  airline: "British Airways",
  origin: "LHR",
  destination: "JFK",
  originCity: "London Heathrow",
  destinationCity: "New York JFK",
  status: "live",
  statusDetail: "FL340",
  percent: 62,
  middle: "2h 10m left",
  departs: "11:40",
  arrives: "14:50",
  gate: "B12",
  aircraft: "B772",
  altitude: "34,000",
  speed: "494",
  registration: "G-VIIL",
  terminal: "5",
  seat: "21A",
  timeline: [["Departed", "11:48", "LHR · Gate B12"], ["Cruising", "12:20", "FL340 · over Cork"], ["Descent", "14:05", "expected"], ["Arrives", "14:50", "JFK · Terminal 7"]]
}, {
  id: "LH431",
  number: "LH431",
  airline: "Lufthansa",
  origin: "FRA",
  destination: "ORD",
  originCity: "Frankfurt",
  destinationCity: "Chicago O'Hare",
  status: "delayed",
  statusDetail: "22 min",
  percent: 0,
  middle: "Departs 13:27",
  departs: "13:05",
  arrives: "15:40",
  gate: "A26",
  aircraft: "A35K",
  altitude: "—",
  speed: "—",
  registration: "D-AIXP",
  terminal: "1",
  seat: "14C",
  timeline: [["Delayed", "13:27", "new departure time"], ["Boarding", "12:55", "Gate A26"], ["Arrives", "16:02", "ORD · Terminal 1"]]
}, {
  id: "SQ317",
  number: "SQ317",
  airline: "Singapore Airlines",
  origin: "SIN",
  destination: "LHR",
  originCity: "Singapore Changi",
  destinationCity: "London Heathrow",
  status: "scheduled",
  percent: 0,
  middle: "Departs 18:40",
  departs: "18:40",
  arrives: "01:10",
  gate: "C21",
  aircraft: "A388",
  altitude: "—",
  speed: "—",
  registration: "9V-SKU",
  terminal: "3",
  seat: "—",
  timeline: [["Scheduled", "18:40", "SIN · Gate C21"], ["Arrives", "01:10", "LHR · Terminal 2"]]
}, {
  id: "AF1281",
  number: "AF1281",
  airline: "Air France",
  origin: "CDG",
  destination: "BCN",
  originCity: "Paris Charles de Gaulle",
  destinationCity: "Barcelona",
  status: "landed",
  percent: 100,
  middle: "Landed 09:52",
  departs: "08:05",
  arrives: "09:52",
  gate: "D14",
  aircraft: "A220",
  altitude: "—",
  speed: "—",
  registration: "F-HZUC",
  terminal: "2F",
  seat: "—",
  timeline: [["Landed", "09:52", "BCN · 8 min early"], ["Departed", "08:05", "CDG · Gate K42"]]
}];
const BOARD = [["BA117", "London Heathrow", "11:40", "B12", "live", "In air"], ["LH431", "Frankfurt", "13:05", "A26", "delayed", "13:27"], ["SQ317", "Singapore", "18:40", "C21", "scheduled", "On time"], ["AF1281", "Paris CDG", "08:05", "D14", "landed", "Landed"], ["UA903", "Newark", "16:20", "C88", "ontime", "On time"], ["EK7", "Dubai", "21:15", "A9", "scheduled", "On time"], ["QF2", "Sydney", "06:05", "B44", "cancelled", "Cancelled"]];
const AIRPORTS = [["LHR", "London Heathrow", "1,284 flights today", "+4 min avg delay"], ["JFK", "New York JFK", "976 flights today", "+11 min avg delay"], ["FRA", "Frankfurt", "1,102 flights today", "On schedule"]];
Object.assign(window, {
  FLIGHTS,
  BOARD,
  AIRPORTS
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/mobile_app/data.js", error: String((e && e.message) || e) }); }

// ui_kits/mobile_app/ios-frame.jsx
try { (() => {
// @ds-adherence-ignore -- omelette starter scaffold (raw elements/hex/px by design)
// Copied omelette starter. Re-running copy_starter_component with this kind overwrites this file with the latest version (page content is unaffected).

/* BEGIN USAGE */
// iOS.jsx — Simplified iOS 26 (Liquid Glass) device frame
// Based on the iOS 26 UI Kit + Figma status bar spec. No assets, no deps.
// Exports (to window): IOSDevice, IOSStatusBar, IOSNavBar, IOSGlassPill, IOSList, IOSListRow, IOSKeyboard
//
// Usage — wrap your screen content in <IOSDevice> to get the bezel, status bar
// and home indicator (props: title, dark, keyboard):
//
//   <IOSDevice title="Settings">
//     ...your screen content...
//   </IOSDevice>
//   <IOSDevice dark title="Search" keyboard>…</IOSDevice>
/* END USAGE */

// ─────────────────────────────────────────────────────────────
// Status bar
// ─────────────────────────────────────────────────────────────
function IOSStatusBar({
  dark = false,
  time = '9:41'
}) {
  const c = dark ? '#fff' : '#000';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 154,
      alignItems: 'center',
      justifyContent: 'center',
      padding: '21px 24px 19px',
      boxSizing: 'border-box',
      position: 'relative',
      zIndex: 20,
      width: '100%'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      height: 22,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      paddingTop: 1.5
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: '-apple-system, "SF Pro", system-ui',
      fontWeight: 590,
      fontSize: 17,
      lineHeight: '22px',
      color: c
    }
  }, time)), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      height: 22,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 7,
      paddingTop: 1,
      paddingRight: 1
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: "19",
    height: "12",
    viewBox: "0 0 19 12"
  }, /*#__PURE__*/React.createElement("rect", {
    x: "0",
    y: "7.5",
    width: "3.2",
    height: "4.5",
    rx: "0.7",
    fill: c
  }), /*#__PURE__*/React.createElement("rect", {
    x: "4.8",
    y: "5",
    width: "3.2",
    height: "7",
    rx: "0.7",
    fill: c
  }), /*#__PURE__*/React.createElement("rect", {
    x: "9.6",
    y: "2.5",
    width: "3.2",
    height: "9.5",
    rx: "0.7",
    fill: c
  }), /*#__PURE__*/React.createElement("rect", {
    x: "14.4",
    y: "0",
    width: "3.2",
    height: "12",
    rx: "0.7",
    fill: c
  })), /*#__PURE__*/React.createElement("svg", {
    width: "17",
    height: "12",
    viewBox: "0 0 17 12"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M8.5 3.2C10.8 3.2 12.9 4.1 14.4 5.6L15.5 4.5C13.7 2.7 11.2 1.5 8.5 1.5C5.8 1.5 3.3 2.7 1.5 4.5L2.6 5.6C4.1 4.1 6.2 3.2 8.5 3.2Z",
    fill: c
  }), /*#__PURE__*/React.createElement("path", {
    d: "M8.5 6.8C9.9 6.8 11.1 7.3 12 8.2L13.1 7.1C11.8 5.9 10.2 5.1 8.5 5.1C6.8 5.1 5.2 5.9 3.9 7.1L5 8.2C5.9 7.3 7.1 6.8 8.5 6.8Z",
    fill: c
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "8.5",
    cy: "10.5",
    r: "1.5",
    fill: c
  })), /*#__PURE__*/React.createElement("svg", {
    width: "27",
    height: "13",
    viewBox: "0 0 27 13"
  }, /*#__PURE__*/React.createElement("rect", {
    x: "0.5",
    y: "0.5",
    width: "23",
    height: "12",
    rx: "3.5",
    stroke: c,
    strokeOpacity: "0.35",
    fill: "none"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "2",
    y: "2",
    width: "20",
    height: "9",
    rx: "2",
    fill: c
  }), /*#__PURE__*/React.createElement("path", {
    d: "M25 4.5V8.5C25.8 8.2 26.5 7.2 26.5 6.5C26.5 5.8 25.8 4.8 25 4.5Z",
    fill: c,
    fillOpacity: "0.4"
  }))));
}

// ─────────────────────────────────────────────────────────────
// Liquid glass pill — blur + tint + shine
// ─────────────────────────────────────────────────────────────
function IOSGlassPill({
  children,
  dark = false,
  style = {}
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      height: 44,
      minWidth: 44,
      borderRadius: 9999,
      position: 'relative',
      overflow: 'hidden',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      boxShadow: dark ? '0 2px 6px rgba(0,0,0,0.35), 0 6px 16px rgba(0,0,0,0.2)' : '0 1px 3px rgba(0,0,0,0.07), 0 3px 10px rgba(0,0,0,0.06)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      borderRadius: 9999,
      backdropFilter: 'blur(12px) saturate(180%)',
      WebkitBackdropFilter: 'blur(12px) saturate(180%)',
      background: dark ? 'rgba(120,120,128,0.28)' : 'rgba(255,255,255,0.5)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      borderRadius: 9999,
      boxShadow: dark ? 'inset 1.5px 1.5px 1px rgba(255,255,255,0.15), inset -1px -1px 1px rgba(255,255,255,0.08)' : 'inset 1.5px 1.5px 1px rgba(255,255,255,0.7), inset -1px -1px 1px rgba(255,255,255,0.4)',
      border: dark ? '0.5px solid rgba(255,255,255,0.15)' : '0.5px solid rgba(0,0,0,0.06)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      zIndex: 1,
      display: 'flex',
      alignItems: 'center',
      padding: '0 4px'
    }
  }, children));
}

// ─────────────────────────────────────────────────────────────
// Navigation bar — glass pills + large title
// ─────────────────────────────────────────────────────────────
function IOSNavBar({
  title = 'Title',
  dark = false,
  trailingIcon = true
}) {
  const muted = dark ? 'rgba(255,255,255,0.6)' : '#404040';
  const text = dark ? '#fff' : '#000';
  const pillIcon = content => /*#__PURE__*/React.createElement(IOSGlassPill, {
    dark: dark
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 36,
      height: 36,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, content));
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 10,
      paddingTop: 62,
      paddingBottom: 10,
      position: 'relative',
      zIndex: 5
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '0 16px'
    }
  }, pillIcon(/*#__PURE__*/React.createElement("svg", {
    width: "12",
    height: "20",
    viewBox: "0 0 12 20",
    fill: "none",
    style: {
      marginLeft: -1
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M10 2L2 10l8 8",
    stroke: muted,
    strokeWidth: "2.5",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }))), trailingIcon && pillIcon(/*#__PURE__*/React.createElement("svg", {
    width: "22",
    height: "6",
    viewBox: "0 0 22 6"
  }, /*#__PURE__*/React.createElement("circle", {
    cx: "3",
    cy: "3",
    r: "2.5",
    fill: muted
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "11",
    cy: "3",
    r: "2.5",
    fill: muted
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "19",
    cy: "3",
    r: "2.5",
    fill: muted
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '0 16px',
      fontFamily: '-apple-system, system-ui',
      fontSize: 34,
      fontWeight: 700,
      lineHeight: '41px',
      color: text,
      letterSpacing: 0.4
    }
  }, title));
}

// ─────────────────────────────────────────────────────────────
// Grouped list (inset card, r:26) + row (52px)
// ─────────────────────────────────────────────────────────────
function IOSListRow({
  title,
  detail,
  icon,
  chevron = true,
  isLast = false,
  dark = false
}) {
  const text = dark ? '#fff' : '#000';
  const sec = dark ? 'rgba(235,235,245,0.6)' : 'rgba(60,60,67,0.6)';
  const ter = dark ? 'rgba(235,235,245,0.3)' : 'rgba(60,60,67,0.3)';
  const sep = dark ? 'rgba(84,84,88,0.65)' : 'rgba(60,60,67,0.12)';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      minHeight: 52,
      padding: '0 16px',
      position: 'relative',
      fontFamily: '-apple-system, system-ui',
      fontSize: 17,
      letterSpacing: -0.43
    }
  }, icon && /*#__PURE__*/React.createElement("div", {
    style: {
      width: 30,
      height: 30,
      borderRadius: 7,
      background: icon,
      marginRight: 12,
      flexShrink: 0
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      color: text
    }
  }, title), detail && /*#__PURE__*/React.createElement("span", {
    style: {
      color: sec,
      marginRight: 6
    }
  }, detail), chevron && /*#__PURE__*/React.createElement("svg", {
    width: "8",
    height: "14",
    viewBox: "0 0 8 14",
    style: {
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M1 1l6 6-6 6",
    stroke: ter,
    strokeWidth: "2",
    fill: "none",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  })), !isLast && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      bottom: 0,
      right: 0,
      left: icon ? 58 : 16,
      height: 0.5,
      background: sep
    }
  }));
}
function IOSList({
  header,
  children,
  dark = false
}) {
  const hc = dark ? 'rgba(235,235,245,0.6)' : 'rgba(60,60,67,0.6)';
  const bg = dark ? '#1C1C1E' : '#fff';
  return /*#__PURE__*/React.createElement("div", null, header && /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: '-apple-system, system-ui',
      fontSize: 13,
      color: hc,
      textTransform: 'uppercase',
      padding: '8px 36px 6px',
      letterSpacing: -0.08
    }
  }, header), /*#__PURE__*/React.createElement("div", {
    style: {
      background: bg,
      borderRadius: 26,
      margin: '0 16px',
      overflow: 'hidden'
    }
  }, children));
}

// ─────────────────────────────────────────────────────────────
// Device frame
// ─────────────────────────────────────────────────────────────
function IOSDevice({
  children,
  width = 402,
  height = 874,
  dark = false,
  title,
  keyboard = false
}) {
  return (
    /*#__PURE__*/
    // data-om-starter: inert presence marker — Claude Design's starter-usage
    // probe reads it; it renders nothing. Keep it on this root element.
    React.createElement("div", {
      "data-om-starter": "ios-frame",
      style: {
        width,
        height,
        borderRadius: 48,
        overflow: 'hidden',
        position: 'relative',
        background: dark ? '#000' : '#F2F2F7',
        boxShadow: '0 40px 80px rgba(0,0,0,0.18), 0 0 0 1px rgba(0,0,0,0.12)',
        fontFamily: '-apple-system, system-ui, sans-serif',
        WebkitFontSmoothing: 'antialiased'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'absolute',
        top: 11,
        left: '50%',
        transform: 'translateX(-50%)',
        width: 126,
        height: 37,
        borderRadius: 24,
        background: '#000',
        zIndex: 50
      }
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        zIndex: 10
      }
    }, /*#__PURE__*/React.createElement(IOSStatusBar, {
      dark: dark
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        height: '100%',
        display: 'flex',
        flexDirection: 'column'
      }
    }, title !== undefined && /*#__PURE__*/React.createElement(IOSNavBar, {
      title: title,
      dark: dark
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        overflow: 'auto'
      }
    }, children), keyboard && /*#__PURE__*/React.createElement(IOSKeyboard, {
      dark: dark
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'absolute',
        bottom: 0,
        left: 0,
        right: 0,
        zIndex: 60,
        height: 34,
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'flex-end',
        paddingBottom: 8,
        pointerEvents: 'none'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        width: 139,
        height: 5,
        borderRadius: 100,
        background: dark ? 'rgba(255,255,255,0.7)' : 'rgba(0,0,0,0.25)'
      }
    })))
  );
}

// ─────────────────────────────────────────────────────────────
// Keyboard — iOS 26 liquid glass
// ─────────────────────────────────────────────────────────────
function IOSKeyboard({
  dark = false
}) {
  const glyph = dark ? 'rgba(255,255,255,0.7)' : '#595959';
  const sugg = dark ? 'rgba(255,255,255,0.6)' : '#333';
  const keyBg = dark ? 'rgba(255,255,255,0.22)' : 'rgba(255,255,255,0.85)';

  // special-key icons
  const icons = {
    shift: /*#__PURE__*/React.createElement("svg", {
      width: "19",
      height: "17",
      viewBox: "0 0 19 17"
    }, /*#__PURE__*/React.createElement("path", {
      d: "M9.5 1L1 9.5h4.5V16h8V9.5H18L9.5 1z",
      fill: glyph
    })),
    del: /*#__PURE__*/React.createElement("svg", {
      width: "23",
      height: "17",
      viewBox: "0 0 23 17"
    }, /*#__PURE__*/React.createElement("path", {
      d: "M7 1h13a2 2 0 012 2v11a2 2 0 01-2 2H7l-6-7.5L7 1z",
      fill: "none",
      stroke: glyph,
      strokeWidth: "1.6",
      strokeLinejoin: "round"
    }), /*#__PURE__*/React.createElement("path", {
      d: "M10 5l7 7M17 5l-7 7",
      stroke: glyph,
      strokeWidth: "1.6",
      strokeLinecap: "round"
    })),
    ret: /*#__PURE__*/React.createElement("svg", {
      width: "20",
      height: "14",
      viewBox: "0 0 20 14"
    }, /*#__PURE__*/React.createElement("path", {
      d: "M18 1v6H4m0 0l4-4M4 7l4 4",
      fill: "none",
      stroke: "#fff",
      strokeWidth: "1.8",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }))
  };
  const key = (content, {
    w,
    flex,
    ret,
    fs = 25,
    k
  } = {}) => /*#__PURE__*/React.createElement("div", {
    key: k,
    style: {
      height: 42,
      borderRadius: 8.5,
      flex: flex ? 1 : undefined,
      width: w,
      minWidth: 0,
      background: ret ? '#08f' : keyBg,
      boxShadow: '0 1px 0 rgba(0,0,0,0.075)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontFamily: '-apple-system, "SF Compact", system-ui',
      fontSize: fs,
      fontWeight: 458,
      color: ret ? '#fff' : glyph
    }
  }, content);
  const row = (keys, pad = 0) => /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 6.5,
      justifyContent: 'center',
      padding: `0 ${pad}px`
    }
  }, keys.map(l => key(l, {
    flex: true,
    k: l
  })));
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      zIndex: 15,
      borderRadius: 27,
      overflow: 'hidden',
      padding: '11px 0 2px',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      boxShadow: dark ? '0 -2px 20px rgba(0,0,0,0.09)' : '0 -1px 6px rgba(0,0,0,0.018), 0 -3px 20px rgba(0,0,0,0.012)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      borderRadius: 27,
      backdropFilter: 'blur(12px) saturate(180%)',
      WebkitBackdropFilter: 'blur(12px) saturate(180%)',
      background: dark ? 'rgba(120,120,128,0.14)' : 'rgba(255,255,255,0.25)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      borderRadius: 27,
      boxShadow: dark ? 'inset 1.5px 1.5px 1px rgba(255,255,255,0.15)' : 'inset 1.5px 1.5px 1px rgba(255,255,255,0.7), inset -1px -1px 1px rgba(255,255,255,0.4)',
      border: dark ? '0.5px solid rgba(255,255,255,0.15)' : '0.5px solid rgba(0,0,0,0.06)',
      pointerEvents: 'none'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 20,
      alignItems: 'center',
      padding: '8px 22px 13px',
      width: '100%',
      boxSizing: 'border-box',
      position: 'relative'
    }
  }, ['"The"', 'the', 'to'].map((w, i) => /*#__PURE__*/React.createElement(React.Fragment, {
    key: i
  }, i > 0 && /*#__PURE__*/React.createElement("div", {
    style: {
      width: 1,
      height: 25,
      background: '#ccc',
      opacity: 0.3
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      textAlign: 'center',
      fontFamily: '-apple-system, system-ui',
      fontSize: 17,
      color: sugg,
      letterSpacing: -0.43,
      lineHeight: '22px'
    }
  }, w)))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 13,
      padding: '0 6.5px',
      width: '100%',
      boxSizing: 'border-box',
      position: 'relative'
    }
  }, row(['q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p']), row(['a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l'], 20), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 14.25,
      alignItems: 'center'
    }
  }, key(icons.shift, {
    w: 45,
    k: 'shift'
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 6.5,
      flex: 1
    }
  }, ['z', 'x', 'c', 'v', 'b', 'n', 'm'].map(l => key(l, {
    flex: true,
    k: l
  }))), key(icons.del, {
    w: 45,
    k: 'del'
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 6,
      alignItems: 'center'
    }
  }, key('ABC', {
    w: 92.25,
    fs: 18,
    k: 'abc'
  }), key('', {
    flex: true,
    k: 'space'
  }), key(icons.ret, {
    w: 92.25,
    ret: true,
    k: 'ret'
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      height: 56,
      width: '100%',
      position: 'relative'
    }
  }));
}
Object.assign(window, {
  IOSDevice,
  IOSStatusBar,
  IOSNavBar,
  IOSGlassPill,
  IOSList,
  IOSListRow,
  IOSKeyboard
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/mobile_app/ios-frame.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web/Showcase.jsx
try { (() => {
const {
  Button,
  Icon,
  Card,
  Badge,
  Tag,
  Stat
} = window.WingbeatDesignSystem_072965;
function SectionHead({
  overline,
  title,
  body,
  align = "start"
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "64ch",
      marginBottom: "var(--space-10)",
      marginInline: align === "center" ? "auto" : undefined,
      textAlign: align === "center" ? "center" : undefined
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "wb-overline"
  }, overline), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontSize: "var(--size-3xl)",
      lineHeight: "var(--leading-tight)",
      letterSpacing: "var(--tracking-heading)",
      fontWeight: "var(--weight-bold)",
      margin: "var(--space-3) 0 var(--space-4)",
      textWrap: "balance"
    }
  }, title), body ? /*#__PURE__*/React.createElement("p", {
    style: {
      ...BODY,
      fontSize: "var(--size-lg)",
      lineHeight: "var(--leading-relaxed)"
    }
  }, body) : null);
}
function OpenSource() {
  return /*#__PURE__*/React.createElement("section", {
    id: "open-source",
    style: {
      background: "var(--surface-page)",
      borderTop: "1px solid var(--border-subtle)",
      borderBottom: "1px solid var(--border-subtle)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      ...SECTION_MAX,
      display: "grid",
      gridTemplateColumns: "minmax(0,1fr) minmax(0,1fr)",
      gap: "var(--space-16)",
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(SectionHead, {
    overline: "AGPL-3.0",
    title: "The whole tracker is open source.",
    body: "Every line that polls Garmin, segments flights and draws the map is public. Read it before you trust it with your fleet, run it on your own Cloudflare account, and fork it if you need something we haven't built."
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "var(--space-3)"
    }
  }, [["file-code", "One Worker and one SQLite database — no build server, no container to babysit."], ["database", "Your tracking data stays in your D1 database. Export or delete it whenever you want."], ["git-pull-request", "Pull requests welcome. Contributors sign a CLA and keep ownership of their work."]].map(([icon, text]) => /*#__PURE__*/React.createElement("div", {
    key: text,
    style: {
      display: "flex",
      gap: "var(--space-3)",
      alignItems: "flex-start"
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: icon,
    size: 20,
    color: "var(--sky-600)"
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      ...BODY,
      fontSize: "var(--size-md)"
    }
  }, text)))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: "var(--space-3)",
      marginTop: "var(--space-8)",
      flexWrap: "wrap"
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    icon: "code",
    href: "https://github.com/willdumm/wingbeat"
  }, "Read the source"), /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    href: "#docs"
  }, "Self-hosting guide"))), /*#__PURE__*/React.createElement(Card, {
    padding: "none",
    elevation: "raised"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "var(--space-2)",
      padding: "var(--space-4) var(--pad-card)",
      borderBottom: "1px solid var(--border-subtle)"
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "terminal",
    size: 16,
    color: "var(--text-subtle)"
  }), /*#__PURE__*/React.createElement("span", {
    className: "wb-overline"
  }, "Deploy your own")), /*#__PURE__*/React.createElement("div", {
    className: "wb-mono",
    style: {
      padding: "var(--pad-card)",
      fontSize: "var(--size-sm)",
      lineHeight: 2,
      color: "var(--text-body)",
      background: "var(--surface-page)",
      overflowX: "auto"
    }
  }, [["$", "wrangler d1 create flight-tracker-db"], ["$", "wrangler d1 migrations apply flight-tracker-db"], ["$", "wrangler secret put POLLER_SECRET"], ["$", "npm run deploy"]].map(([p, cmd]) => /*#__PURE__*/React.createElement("div", {
    key: cmd,
    style: {
      whiteSpace: "pre"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--text-subtle)"
    }
  }, p, " "), cmd)), /*#__PURE__*/React.createElement("div", {
    style: {
      whiteSpace: "pre",
      color: "var(--text-subtle)"
    }
  }, "# then open Settings and add a tracker")))));
}
const FEATURES = [["plane", "Flights, not points", "Position reports are segmented into flights automatically. Takeoff and landing are detected from velocity — nobody types a time into a form."], ["map-pin", "Places, not coordinates", "Boundary points are reverse-geocoded, so history reads Kodiak → Larsen Bay instead of two decimal pairs. Named points and regions you define are drawn on the map too."], ["bell", "Takeoff, landing and signal gaps", "Notifications fire the moment an aircraft leaves the ground, lands, or goes quiet in flight for longer than your gap threshold. Pushover natively, or a JSON webhook to anything else."], ["layers", "Four basemaps", "Topo, USGS, satellite and street tiles. Terrain matters when the route is a fjord, so the map is built to switch."], ["building-2", "Aircraft, pilots and trackers", "All three are records, not labels. Move a tracker to another airframe and the flight history follows the aircraft, not the device."], ["sliders-horizontal", "Configured in the browser", "App name, timezone, default map view, gap threshold and notification targets are all settings. No redeploy to change a name."], ["users", "Invite-only accounts", "Admins and viewers, sessions stored in your own database. No public sign-up and no third-party identity provider in the path."], ["radio", "Built for the hardware you have", "Garmin inReach over MapShare today, polled once a minute and throttled to the device's transmission rate. The poller is factored so other tracker types can be added."]];
function Features() {
  return /*#__PURE__*/React.createElement("section", {
    id: "features",
    style: SECTION_MAX
  }, /*#__PURE__*/React.createElement(SectionHead, {
    overline: "Features",
    title: "What it does with a position report.",
    body: "An inReach sends a point every couple of minutes. Everything below is what the tracker builds out of that stream."
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(4,minmax(0,1fr))",
      gap: "var(--space-6)"
    }
  }, FEATURES.map(([icon, title, body]) => /*#__PURE__*/React.createElement(Card, {
    key: title,
    padding: "lg"
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      width: 40,
      height: 40,
      borderRadius: "var(--radius-md)",
      background: "var(--surface-brand-soft)",
      alignItems: "center",
      justifyContent: "center",
      marginBottom: "var(--space-4)"
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: icon,
    size: 20,
    color: "var(--sky-600)"
  })), /*#__PURE__*/React.createElement("h3", {
    style: {
      fontSize: "var(--size-lg)",
      fontWeight: "var(--weight-bold)",
      marginBottom: "var(--space-2)"
    }
  }, title), /*#__PURE__*/React.createElement("p", {
    style: BODY
  }, body)))));
}
const STEPS = [["01", "The inReach transmits", "Your pilots carry the device they already fly with. MapShare publishes its position roughly every two minutes."], ["02", "The Worker polls the feed", "A cron trigger runs every minute, fetches each tracker's KML feed, and writes new points into your D1 database."], ["03", "Points become flights", "Segmentation groups the stream into flights, geocodes the endpoints, and the dashboard draws the track. Notifications go out as events are detected."]];
function HowItWorks() {
  return /*#__PURE__*/React.createElement("section", {
    id: "how",
    style: {
      background: "var(--surface-page)",
      borderTop: "1px solid var(--border-subtle)",
      borderBottom: "1px solid var(--border-subtle)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: SECTION_MAX
  }, /*#__PURE__*/React.createElement(SectionHead, {
    overline: "How it works",
    title: "Three moving parts between the aircraft and the map."
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(3,minmax(0,1fr))",
      gap: "var(--space-6)"
    }
  }, STEPS.map(([n, title, body]) => /*#__PURE__*/React.createElement(Card, {
    key: n,
    padding: "lg"
  }, /*#__PURE__*/React.createElement("span", {
    className: "wb-mono",
    style: {
      fontSize: "var(--size-xl)",
      fontWeight: 600,
      color: "var(--sky-500)"
    }
  }, n), /*#__PURE__*/React.createElement("h3", {
    style: {
      fontSize: "var(--size-lg)",
      fontWeight: "var(--weight-bold)",
      margin: "var(--space-3) 0 var(--space-2)"
    }
  }, title), /*#__PURE__*/React.createElement("p", {
    style: BODY
  }, body))))));
}
const PLANS = [{
  name: "Self-host",
  price: "Free",
  note: "AGPL-3.0",
  body: "You deploy the Worker, create the database and add your trackers. Fine for personal, club or internal use, or any deployment that publishes its source.",
  points: ["Full feature set, no limits", "Your Cloudflare account and data", "Community support on GitHub"],
  cta: "Read the setup guide",
  href: "#docs",
  variant: "secondary"
}, {
  name: "Hosted",
  price: "Talk to us",
  note: "Managed",
  featured: true,
  body: "We run the deployment, connect your inReach feeds, and keep it updated. You get a domain, an admin account and someone to call when a tracker stops reporting.",
  points: ["Setup and tracker onboarding included", "Updates, monitoring and backups", "Notification targets configured for your crew"],
  cta: "Get in touch",
  href: "mailto:hello@example.com",
  variant: "accent"
}, {
  name: "Commercial license",
  price: "Talk to us",
  note: "Dual-licensed",
  body: "For operators who want to run the software as a paid service for their own customers, or inside a closed-source product, without the AGPL's source-disclosure obligation.",
  points: ["No network-copyleft obligation", "Closed operator layer permitted", "Support terms negotiated separately"],
  cta: "Ask about licensing",
  href: "mailto:hello@example.com",
  variant: "secondary"
}];
function Hosting() {
  return /*#__PURE__*/React.createElement("section", {
    id: "hosting",
    style: SECTION_MAX
  }, /*#__PURE__*/React.createElement(SectionHead, {
    align: "center",
    overline: "Hosting",
    title: "Run it yourself, or let us run it.",
    body: "The software is the same in every column. What changes is who keeps it running and which licence you need."
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(3,minmax(0,1fr))",
      gap: "var(--space-6)",
      alignItems: "start"
    }
  }, PLANS.map(p => /*#__PURE__*/React.createElement(Card, {
    key: p.name,
    padding: "lg",
    elevation: p.featured ? "raised" : "default"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "var(--space-3)",
      minHeight: 52,
      alignItems: "flex-start",
      flexWrap: "wrap"
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontSize: "var(--size-lg)",
      fontWeight: "var(--weight-bold)"
    }
  }, p.name), p.featured ? /*#__PURE__*/React.createElement(Badge, {
    tone: "accent"
  }, p.note) : /*#__PURE__*/React.createElement(Badge, null, p.note)), /*#__PURE__*/React.createElement("div", {
    className: "wb-mono",
    style: {
      fontSize: "var(--size-2xl)",
      fontWeight: 600,
      margin: "var(--space-4) 0 var(--space-4)"
    }
  }, p.price), /*#__PURE__*/React.createElement("p", {
    style: {
      ...BODY,
      minHeight: "7.5em"
    }
  }, p.body), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "var(--space-2)",
      margin: "var(--space-5) 0 var(--space-6)"
    }
  }, p.points.map(pt => /*#__PURE__*/React.createElement("div", {
    key: pt,
    style: {
      display: "flex",
      gap: "var(--space-2)",
      alignItems: "flex-start"
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "check",
    size: 16,
    color: "var(--ontime-500)"
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-body)",
      fontSize: "var(--size-sm)",
      lineHeight: "var(--leading-normal)",
      color: "var(--text-body)"
    }
  }, pt)))), /*#__PURE__*/React.createElement(Button, {
    variant: p.variant,
    fullWidth: true,
    href: p.href
  }, p.cta)))), /*#__PURE__*/React.createElement("p", {
    style: {
      ...BODY,
      fontSize: "var(--size-sm)",
      textAlign: "center",
      marginTop: "var(--space-6)"
    }
  }, "Not sure which one you need? The AGPL only asks you to publish your source if you run a modified version as a network service."));
}
function DocsBand() {
  return /*#__PURE__*/React.createElement("section", {
    id: "docs",
    style: {
      background: "var(--surface-brand)",
      color: "var(--text-inverse)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      ...SECTION_MAX,
      display: "grid",
      gridTemplateColumns: "minmax(0,1.2fr) minmax(0,1fr)",
      gap: "var(--space-16)",
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("span", {
    className: "wb-overline",
    style: {
      color: "var(--sky-100)"
    }
  }, "Documentation"), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontSize: "var(--size-3xl)",
      lineHeight: "var(--leading-tight)",
      letterSpacing: "var(--tracking-heading)",
      fontWeight: "var(--weight-bold)",
      color: "var(--text-inverse)",
      margin: "var(--space-3) 0 var(--space-4)"
    }
  }, "Setup, tracker onboarding, every API route."), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "var(--font-body)",
      fontSize: "var(--size-lg)",
      lineHeight: "var(--leading-relaxed)",
      color: "var(--sky-100)",
      maxWidth: "50ch",
      margin: 0
    }
  }, "Deploying your own instance, pointing a Garmin MapShare feed at it, adding pilots and aircraft, and wiring up notifications \u2014 written for the person doing it, not the person who wrote it."), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: "var(--space-8)"
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "inverse",
    size: "lg",
    iconAfter: "arrow-right",
    href: "#docs"
  }, "Open the docs"))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gap: "var(--space-3)"
    }
  }, ["Deploy to Cloudflare", "Get your MapShare feed URL", "Add aircraft, pilots and trackers", "Notification targets", "API reference"].map(t => /*#__PURE__*/React.createElement("a", {
    key: t,
    href: "#docs",
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      gap: "var(--space-4)",
      padding: "var(--space-4) var(--space-5)",
      borderRadius: "var(--radius-md)",
      background: "var(--sky-600)",
      border: "1px solid var(--sky-400)",
      fontFamily: "var(--font-ui)",
      fontSize: "var(--size-md)",
      fontWeight: 600,
      color: "var(--text-inverse)",
      textDecoration: "none"
    }
  }, t, /*#__PURE__*/React.createElement(Icon, {
    name: "chevron-right",
    size: 16
  }))))));
}
Object.assign(window, {
  SectionHead,
  OpenSource,
  Features,
  HowItWorks,
  Hosting,
  DocsBand
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web/Showcase.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web/Site.jsx
try { (() => {
const {
  Logo,
  Button,
  Icon,
  Card,
  Badge,
  Tag,
  FlightStatusBadge,
  Stat
} = window.WingbeatDesignSystem_072965;
const SECTION_MAX = {
  maxWidth: "var(--content-max)",
  margin: "0 auto",
  padding: "var(--space-20) var(--pad-page-x)"
};
const BODY = {
  fontFamily: "var(--font-body)",
  fontSize: "var(--size-md)",
  lineHeight: "var(--leading-normal)",
  color: "var(--text-muted)",
  margin: 0
};
function SiteHeader() {
  const nav = [["Features", "#features"], ["How it works", "#how"], ["Open source", "#open-source"], ["Hosting", "#hosting"]];
  return /*#__PURE__*/React.createElement("header", {
    style: {
      position: "sticky",
      top: 0,
      zIndex: 30,
      background: "var(--glass-bg)",
      backdropFilter: "var(--glass-blur)",
      WebkitBackdropFilter: "var(--glass-blur)",
      borderBottom: "1px solid var(--border-subtle)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--content-max)",
      margin: "0 auto",
      padding: "0 var(--pad-page-x)",
      height: 68,
      display: "flex",
      alignItems: "center",
      gap: "var(--space-8)"
    }
  }, /*#__PURE__*/React.createElement(Logo, {
    size: 24
  }), /*#__PURE__*/React.createElement("nav", {
    style: {
      display: "flex",
      gap: "var(--space-6)"
    }
  }, nav.map(([label, href]) => /*#__PURE__*/React.createElement("a", {
    key: label,
    href: href,
    style: {
      fontFamily: "var(--font-ui)",
      fontSize: "var(--size-md)",
      fontWeight: 600,
      color: "var(--text-muted)",
      textDecoration: "none",
      padding: "6px 0"
    }
  }, label))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginLeft: "auto",
      display: "flex",
      alignItems: "center",
      gap: "var(--space-3)"
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    size: "md",
    href: "#docs"
  }, "Docs"), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "md",
    href: "#hosting"
  }, "Hosting options"))));
}
const FLEET = [{
  tail: "N728SH",
  status: "live",
  detail: "14:50",
  route: "Kodiak → Larsen Bay",
  telemetry: "57.790, -152.410 · 1,400 ft · 96 kt",
  time: "14:50"
}, {
  tail: "N512KD",
  status: "landed",
  detail: "09:52",
  route: "Port Lions → Kodiak",
  telemetry: "Blocked in · 28 min flight",
  time: "09:52"
}, {
  tail: "N904AK",
  status: "scheduled",
  detail: "15:20",
  route: "Kodiak → Old Harbor",
  telemetry: "Tracker online · last report 14:46",
  time: "15:20"
}];
function Hero() {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      position: "relative",
      overflow: "hidden",
      background: "var(--sky-50)",
      borderBottom: "1px solid var(--border-subtle)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      backgroundImage: "linear-gradient(var(--sky-100) 1px,transparent 1px),linear-gradient(90deg,var(--sky-100) 1px,transparent 1px)",
      backgroundSize: "56px 56px",
      opacity: 0.9
    }
  }), /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 1280 420",
    style: {
      position: "absolute",
      inset: 0,
      width: "100%",
      height: "100%"
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M-40 380 C 300 300, 620 150, 1320 60",
    fill: "none",
    stroke: "var(--sky-300)",
    strokeWidth: "2",
    strokeDasharray: "8 9"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M-40 430 C 380 400, 700 330, 1320 200",
    fill: "none",
    stroke: "var(--sky-200)",
    strokeWidth: "2"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      maxWidth: "var(--content-max)",
      margin: "0 auto",
      padding: "var(--space-24) var(--pad-page-x)",
      display: "grid",
      gridTemplateColumns: "minmax(0,1.05fr) minmax(0,0.95fr)",
      gap: "var(--space-16)",
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("span", {
    className: "wb-overline",
    style: {
      color: "var(--dusk-600)"
    }
  }, "Open source \xB7 AGPL-3.0"), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontSize: "var(--size-5xl)",
      lineHeight: "var(--leading-tight)",
      letterSpacing: "var(--tracking-display)",
      fontWeight: "var(--weight-extrabold)",
      margin: "var(--space-4) 0 var(--space-5)",
      textWrap: "balance"
    }
  }, "Know where the aircraft is."), /*#__PURE__*/React.createElement("p", {
    style: {
      ...BODY,
      fontSize: "var(--size-lg)",
      lineHeight: "var(--leading-relaxed)",
      maxWidth: "48ch"
    }
  }, "Flight tracking for small air taxi operations, built on the Garmin inReach your pilots already carry. It polls the MapShare feed, turns position reports into flights, and puts the whole fleet on one map. Host it yourself or let us run it."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: "var(--space-3)",
      marginTop: "var(--space-8)",
      flexWrap: "wrap"
    }
  }, /*#__PURE__*/React.createElement(Button, {
    size: "lg",
    variant: "primary",
    href: "#hosting"
  }, "See hosting options"), /*#__PURE__*/React.createElement(Button, {
    size: "lg",
    variant: "secondary",
    icon: "code",
    href: "https://github.com/willdumm/wingbeat"
  }, "Read the source")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: "var(--space-2)",
      marginTop: "var(--space-5)",
      flexWrap: "wrap"
    }
  }, ["Garmin inReach", "Cloudflare Workers + D1", "No app to install"].map(t => /*#__PURE__*/React.createElement(Tag, {
    key: t
  }, t)))), /*#__PURE__*/React.createElement(Card, {
    padding: "lg",
    elevation: "raised"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "var(--space-3)",
      marginBottom: "var(--space-5)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "wb-overline"
  }, "Fleet \xB7 3 aircraft"), /*#__PURE__*/React.createElement("span", {
    className: "wb-mono",
    style: {
      marginLeft: "auto",
      fontSize: "var(--size-xs)",
      color: "var(--text-subtle)"
    }
  }, "14:51")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "var(--space-4)"
    }
  }, FLEET.map(f => /*#__PURE__*/React.createElement("div", {
    key: f.tail,
    style: {
      display: "flex",
      alignItems: "flex-start",
      gap: "var(--space-4)",
      paddingBottom: "var(--space-4)",
      borderBottom: "1px solid var(--border-subtle)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      minWidth: 0,
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "var(--space-3)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "wb-mono",
    style: {
      fontSize: "var(--size-md)",
      fontWeight: 600
    }
  }, f.tail), /*#__PURE__*/React.createElement(FlightStatusBadge, {
    status: f.status,
    detail: f.detail
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-ui)",
      fontSize: "var(--size-sm)",
      fontWeight: 600,
      marginTop: "var(--space-2)"
    }
  }, f.route), /*#__PURE__*/React.createElement("div", {
    className: "wb-mono",
    style: {
      fontSize: "var(--size-xs)",
      color: "var(--text-subtle)",
      marginTop: 2
    }
  }, f.telemetry))))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: "var(--space-8)",
      marginTop: "var(--space-4)"
    }
  }, /*#__PURE__*/React.createElement(Stat, {
    label: "Feed polled",
    value: "60",
    unit: "s"
  }), /*#__PURE__*/React.createElement(Stat, {
    label: "Flights logged",
    value: "1,284"
  }), /*#__PURE__*/React.createElement(Stat, {
    label: "Your data",
    value: "D1"
  })))));
}
function SiteFooter() {
  const cols = [["Product", [["Features", "#features"], ["How it works", "#how"], ["Hosting", "#hosting"]]], ["Documentation", [["Setup", "#docs"], ["Add a tracker", "#docs"], ["Notifications", "#docs"], ["API routes", "#docs"]]], ["Project", [["GitHub", "https://github.com/willdumm/wingbeat"], ["AGPL-3.0", "#open-source"], ["Commercial license", "#hosting"], ["Contributing", "#open-source"]]]];
  return /*#__PURE__*/React.createElement("footer", {
    style: {
      background: "var(--surface-inverse)",
      color: "var(--ink-300)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--content-max)",
      margin: "0 auto",
      padding: "var(--space-16) var(--pad-page-x)",
      display: "grid",
      gridTemplateColumns: "minmax(0,1.4fr) repeat(3,minmax(0,1fr))",
      gap: "var(--space-10)"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Logo, {
    size: 22,
    tone: "mono-white"
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "var(--font-body)",
      fontSize: "var(--size-sm)",
      lineHeight: "var(--leading-normal)",
      color: "var(--ink-400)",
      maxWidth: "34ch",
      marginTop: "var(--space-4)"
    }
  }, "Fleet tracking for operators who fly where the coverage ends.")), cols.map(([head, links]) => /*#__PURE__*/React.createElement("div", {
    key: head
  }, /*#__PURE__*/React.createElement("span", {
    className: "wb-overline",
    style: {
      color: "var(--ink-400)"
    }
  }, head), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "var(--space-2)",
      marginTop: "var(--space-3)"
    }
  }, links.map(([l, href]) => /*#__PURE__*/React.createElement("a", {
    key: l,
    href: href,
    style: {
      fontFamily: "var(--font-body)",
      fontSize: "var(--size-md)",
      color: "var(--ink-200)"
    }
  }, l)))))), /*#__PURE__*/React.createElement("div", {
    style: {
      borderTop: "1px solid var(--ink-800)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--content-max)",
      margin: "0 auto",
      padding: "var(--space-5) var(--pad-page-x)",
      display: "flex",
      justifyContent: "space-between",
      fontFamily: "var(--font-body)",
      fontSize: "var(--size-xs)",
      color: "var(--ink-500)"
    }
  }, /*#__PURE__*/React.createElement("span", null, "\xA9 2026 Wingbeat"), /*#__PURE__*/React.createElement("span", {
    className: "wb-mono"
  }, "AGPL-3.0 \xB7 Garmin inReach \xB7 Cloudflare Workers + D1"))));
}
Object.assign(window, {
  SiteHeader,
  Hero,
  SiteFooter,
  SECTION_MAX,
  BODY
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web/Site.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Logo = __ds_scope.Logo;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.CardHeader = __ds_scope.CardHeader;

__ds_ns.Icon = __ds_scope.Icon;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.Tag = __ds_scope.Tag;

__ds_ns.Dialog = __ds_scope.Dialog;

__ds_ns.Toast = __ds_scope.Toast;

__ds_ns.Tooltip = __ds_scope.Tooltip;

__ds_ns.FlightCard = __ds_scope.FlightCard;

__ds_ns.FlightProgress = __ds_scope.FlightProgress;

__ds_ns.FlightStatusBadge = __ds_scope.FlightStatusBadge;

__ds_ns.Stat = __ds_scope.Stat;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.Field = __ds_scope.Field;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Radio = __ds_scope.Radio;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.Switch = __ds_scope.Switch;

__ds_ns.Tabs = __ds_scope.Tabs;

})();
