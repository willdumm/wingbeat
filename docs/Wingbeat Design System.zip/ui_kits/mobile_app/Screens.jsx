const { Icon, IconButton, Card, Button, FlightStatusBadge, FlightProgress, Stat, Tabs } =
  window.WingbeatDesignSystem_072965;

function LiveScreen({ onOpen, onSearch }) {
  const [sel, setSel] = React.useState("BA117");
  const f = FLIGHTS.find((x) => x.id === sel) || FLIGHTS[0];
  return (
    <div style={{ position: "absolute", inset: 0 }}>
      <MapGround />
      <div style={{ position: "absolute", top: 0, left: 0, right: 0 }}>
        <AppHeader onSearch={onSearch} query="" />
      </div>

      <div style={{ position: "absolute", top: 150, right: "var(--pad-screen-x)", display: "flex", flexDirection: "column", gap: "var(--space-2)", zIndex: 25 }}>
        <IconButton icon="layers" label="Map layers" variant="glass" />
        <IconButton icon="crosshair" label="Centre on me" variant="glass" />
        <IconButton icon="cloud-sun" label="Weather" variant="glass" />
      </div>

      <PlaneMarker x={214} y={330} rotate={-38} active label="BA117" onClick={() => setSel("BA117")} />
      <PlaneMarker x={108} y={452} rotate={-12} onClick={() => setSel("AF1281")} />
      <PlaneMarker x={306} y={252} rotate={-54} onClick={() => setSel("SQ317")} />
      <PlaneMarker x={168} y={548} rotate={22} onClick={() => setSel("LH431")} />

      <div style={{ position: "absolute", left: 0, right: 0, bottom: TAB_H + HOME_H, padding: "var(--space-3) var(--pad-screen-x) var(--space-4)", zIndex: 30 }}>
        <Card padding="none" elevation="raised" style={{ borderRadius: "var(--radius-xl)" }}>
          <div style={{ padding: "var(--pad-card)", display: "flex", flexDirection: "column", gap: "var(--space-4)" }}>
            <div style={{ display: "flex", alignItems: "center", gap: "var(--space-3)" }}>
              <span className="wb-fc__no">{f.number}</span>
              <span className="wb-fc__airline">{f.airline}</span>
              <span style={{ marginLeft: "auto" }}><FlightStatusBadge status={f.status} detail={f.statusDetail} /></span>
            </div>
            <FlightProgress origin={f.origin} destination={f.destination} originCity={f.originCity}
              destinationCity={f.destinationCity} percent={f.percent} middle={f.middle}
              showPlane={f.status === "live"} />
            <div style={{ display: "flex", gap: "var(--space-6)", paddingTop: "var(--space-3)", borderTop: "1px solid var(--border-subtle)" }}>
              <Stat label="Altitude" value={f.altitude} unit="ft" size="sm" />
              <Stat label="Speed" value={f.speed} unit="kt" size="sm" />
              <Stat label="Gate" value={f.gate} size="sm" />
              <span style={{ marginLeft: "auto" }}>
                <Button size="sm" variant="ghost" iconAfter="chevron-right" onClick={() => onOpen(f.id)}>Details</Button>
              </span>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}

function WatchlistScreen({ onOpen }) {
  const [tab, setTab] = React.useState("all");
  const list = tab === "all" ? FLIGHTS : FLIGHTS.filter((f) => f.status === "live" || f.status === "delayed");
  const { FlightCard } = window.WingbeatDesignSystem_072965;
  return (
    <div style={{ position: "absolute", inset: 0, overflowY: "auto", background: "var(--surface-page)" }}>
      <div style={{ paddingTop: SB_H }} />
      <ScreenTitle action={<Button size="sm" variant="ghost" icon="plus">Add flight</Button>}>Watchlist</ScreenTitle>
      <div style={{ padding: "0 var(--pad-screen-x) var(--space-4)" }}>
        <Tabs variant="pill" value={tab} onChange={setTab} items={[{ id: "all", label: "All 4" }, { id: "today", label: "Active" }]} />
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: "var(--space-4)", padding: `0 var(--pad-screen-x) ${TAB_H + HOME_H + 24}px` }}>
        {list.map((f) => (
          <FlightCard key={f.id} flight={f} pinned onPin={() => {}} onClick={() => onOpen(f.id)} />
        ))}
      </div>
    </div>
  );
}

function AirportsScreen() {
  const rows = [
    ["LHR", "London Heathrow", "1,284", "+4 min", "ontime"],
    ["JFK", "New York JFK", "976", "+11 min", "delayed"],
    ["FRA", "Frankfurt", "1,102", "On schedule", "ontime"],
    ["SIN", "Singapore Changi", "864", "+2 min", "ontime"],
    ["CDG", "Paris CDG", "1,031", "+18 min", "delayed"]
  ];
  return (
    <div style={{ position: "absolute", inset: 0, overflowY: "auto", background: "var(--surface-page)" }}>
      <div style={{ paddingTop: SB_H }} />
      <ScreenTitle>Airports</ScreenTitle>
      <div style={{ padding: `0 var(--pad-screen-x) ${TAB_H + HOME_H + 24}px` }}>
        <Card padding="none">
          {rows.map(([code, name, count, delay, tone], i) => (
            <div key={code} style={{
              display: "flex", alignItems: "center", gap: "var(--space-4)",
              padding: "var(--space-4) var(--pad-card)",
              borderTop: i ? "1px solid var(--border-subtle)" : "none"
            }}>
              <span style={{
                fontFamily: "var(--font-mono)", fontSize: "var(--size-md)", fontWeight: 600,
                color: "var(--sky-700)", background: "var(--surface-brand-soft)",
                borderRadius: "var(--radius-sm)", padding: "6px 8px", width: 52, textAlign: "center"
              }}>{code}</span>
              <span style={{ minWidth: 0, flex: 1 }}>
                <span style={{ display: "block", fontFamily: "var(--font-ui)", fontSize: "var(--size-md)", fontWeight: 600, color: "var(--text-strong)" }}>{name}</span>
                <span style={{ display: "block", fontFamily: "var(--font-body)", fontSize: "var(--size-xs)", color: "var(--text-muted)" }}>{count} flights today</span>
              </span>
              <FlightStatusBadge status={tone} detail={delay.startsWith("+") ? delay : null} />
              <Icon name="chevron-right" size={18} color="var(--text-subtle)" />
            </div>
          ))}
        </Card>
      </div>
    </div>
  );
}

Object.assign(window, { LiveScreen, WatchlistScreen, AirportsScreen });
