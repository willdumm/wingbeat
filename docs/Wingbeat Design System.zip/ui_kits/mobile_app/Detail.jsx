const { Icon, IconButton, Card, Button, FlightStatusBadge, FlightProgress, Stat, Switch,
  Checkbox, Radio, Select, Field, Input, Tag, Badge, Dialog, Toast } = window.WingbeatDesignSystem_072965;

function DetailScreen({ id, onBack, onToast }) {
  const f = FLIGHTS.find((x) => x.id === id) || FLIGHTS[0];
  const [ask, setAsk] = React.useState(false);
  return (
    <div style={{ position: "absolute", inset: 0, background: "var(--surface-page)", overflowY: "auto" }}>
      <div style={{ position: "relative", height: 300, background: "var(--surface-map)" }}>
        <MapGround height="300px" />
        <div style={{ position: "absolute", top: SB_H, left: "var(--pad-screen-x)", right: "var(--pad-screen-x)", display: "flex", justifyContent: "space-between", zIndex: 5 }}>
          <IconButton icon="arrow-left" label="Back" variant="glass" onClick={onBack} />
          <div style={{ display: "flex", gap: "var(--space-2)" }}>
            <IconButton icon="share-2" label="Share" variant="glass" />
            <IconButton icon="bookmark-check" label="Tracking" variant="glass" />
          </div>
        </div>
        <PlaneMarker x={230} y={190} rotate={-38} active />
        <div style={{ position: "absolute", left: 0, right: 0, bottom: 0, height: 96, background: "var(--scrim-bottom)", display: "flex", alignItems: "flex-end", padding: "var(--space-4) var(--pad-screen-x)" }}>
          <span style={{ fontFamily: "var(--font-mono)", color: "#fff", fontSize: "var(--size-md)", fontWeight: 600, letterSpacing: "var(--tracking-wide)" }}>
            {f.origin} → {f.destination} · {f.status === "live" ? `${f.statusDetail} · ${f.speed} kt` : "On the ground"}
          </span>
        </div>
      </div>

      <div style={{ padding: "var(--space-5) var(--pad-screen-x)", display: "flex", flexDirection: "column", gap: "var(--space-4)", paddingBottom: HOME_H + 32 }}>
        <div style={{ display: "flex", alignItems: "center", gap: "var(--space-3)" }}>
          <span style={{ fontFamily: "var(--font-mono)", fontSize: "var(--size-xl)", fontWeight: 600, color: "var(--text-strong)" }}>{f.number}</span>
          <span style={{ fontFamily: "var(--font-body)", fontSize: "var(--size-sm)", color: "var(--text-muted)" }}>{f.airline}</span>
          <span style={{ marginLeft: "auto" }}><FlightStatusBadge status={f.status} detail={f.statusDetail} /></span>
        </div>

        <Card><FlightProgress origin={f.origin} destination={f.destination} originCity={f.originCity}
          destinationCity={f.destinationCity} percent={f.percent} middle={f.middle} showPlane={f.status === "live"} /></Card>

        <Card>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: "var(--space-5) var(--space-4)" }}>
            <Stat label="Departs" value={f.departs} />
            <Stat label="Arrives" value={f.arrives} />
            <Stat label="Gate" value={f.gate} />
            <Stat label="Terminal" value={f.terminal} />
            <Stat label="Aircraft" value={f.aircraft} />
            <Stat label="Reg" value={f.registration} />
          </div>
        </Card>

        <Card padding="none">
          <div className="wb-card__header"><span className="wb-card__title">Timeline</span>
            <Badge tone="brand" dot>Updated 15s ago</Badge></div>
          <div style={{ padding: "var(--pad-card)", display: "flex", flexDirection: "column", gap: "var(--space-4)" }}>
            {f.timeline.map(([t, time, note], i) => (
              <div key={t} style={{ display: "flex", gap: "var(--space-3)", alignItems: "flex-start" }}>
                <span style={{ width: 9, height: 9, marginTop: 6, borderRadius: "var(--radius-full)", flex: "none", background: i === 0 ? "var(--dusk-500)" : "var(--ink-200)" }} />
                <span style={{ flex: 1, minWidth: 0 }}>
                  <span style={{ display: "block", fontFamily: "var(--font-ui)", fontSize: "var(--size-md)", fontWeight: 600, color: "var(--text-strong)" }}>{t}</span>
                  <span style={{ display: "block", fontFamily: "var(--font-body)", fontSize: "var(--size-xs)", color: "var(--text-muted)" }}>{note}</span>
                </span>
                <span className="wb-mono" style={{ fontSize: "var(--size-md)", color: "var(--text-body)" }}>{time}</span>
              </div>
            ))}
          </div>
        </Card>

        <div style={{ display: "flex", gap: "var(--space-3)" }}>
          <Button variant="primary" icon="bell" fullWidth onClick={() => onToast()}>Alert me</Button>
          <Button variant="secondary" icon="bell-off" onClick={() => setAsk(true)}>Stop</Button>
        </div>
      </div>

      <Dialog open={ask} title={`Stop tracking ${f.number}?`} onClose={() => setAsk(false)}
        footer={<><Button variant="secondary" onClick={() => setAsk(false)}>Keep tracking</Button>
          <Button variant="danger" onClick={() => setAsk(false)}>Stop tracking</Button></>}>
        You'll no longer get gate or delay alerts for this flight.
      </Dialog>
    </div>
  );
}

function AlertsScreen() {
  const [push, setPush] = React.useState(true);
  const [gate, setGate] = React.useState(true);
  const [code, setCode] = React.useState(false);
  const [ch, setCh] = React.useState("Push");
  return (
    <div style={{ position: "absolute", inset: 0, overflowY: "auto", background: "var(--surface-page)" }}>
      <div style={{ paddingTop: SB_H }} />
      <ScreenTitle>Alerts</ScreenTitle>
      <div style={{ padding: `0 var(--pad-screen-x) ${TAB_H + HOME_H + 24}px`, display: "flex", flexDirection: "column", gap: "var(--space-4)" }}>
        <Toast tone="delayed" title="LH431 now 22 min late" message="New departure 13:27 · Gate A26" actionLabel="View" />
        <Toast tone="ontime" title="AF1281 has landed" message="Arrived 09:52 at BCN, 8 minutes early" />

        <Card padding="none">
          <div className="wb-card__header"><span className="wb-card__title">Notifications</span></div>
          <div style={{ padding: "var(--pad-card)", display: "flex", flexDirection: "column", gap: "var(--space-5)" }}>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: "var(--space-4)" }}>
              <span style={{ fontFamily: "var(--font-ui)", fontSize: "var(--size-md)", fontWeight: 600, color: "var(--text-strong)" }}>Push alerts</span>
              <Switch checked={push} onChange={() => setPush(!push)} />
            </div>
            <Checkbox checked={gate} onChange={() => setGate(!gate)} label="Alert me on gate changes" />
            <Checkbox checked={code} onChange={() => setCode(!code)} label="Include codeshare flights" />
            <Field label="Alert me when">
              <Select value="delay" options={[{ value: "dep", label: "It departs" }, { value: "delay", label: "It's delayed 15+ min" }, { value: "gate", label: "The gate changes" }]} />
            </Field>
            <div>
              <span className="wb-overline" style={{ display: "block", marginBottom: "var(--space-2)" }}>Channel</span>
              <div style={{ display: "flex", gap: "var(--space-5)" }}>
                {["Push", "Email", "Both"].map((o) => (
                  <Radio key={o} name="ch" value={o} label={o} checked={ch === o} onChange={() => setCh(o)} />
                ))}
              </div>
            </div>
          </div>
        </Card>

        <Card>
          <span className="wb-overline" style={{ display: "block", marginBottom: "var(--space-3)" }}>Quiet hours</span>
          <div style={{ display: "flex", gap: "var(--space-3)", alignItems: "flex-end" }}>
            <Field label="From" className="wb-grow"><Input mono value="23:00" /></Field>
            <Field label="To"><Input mono value="07:00" /></Field>
          </div>
          <div style={{ display: "flex", gap: "var(--space-2)", marginTop: "var(--space-4)", flexWrap: "wrap" }}>
            <Tag icon="moon" selected onClick={() => {}}>Overnight</Tag>
            <Tag onClick={() => {}}>Weekends</Tag>
            <Tag onClick={() => {}}>Never</Tag>
          </div>
        </Card>
      </div>
    </div>
  );
}

Object.assign(window, { DetailScreen, AlertsScreen });
