const FLIGHTS = [
  { id:"BA117", number:"BA117", airline:"British Airways", origin:"LHR", destination:"JFK",
    originCity:"London Heathrow", destinationCity:"New York JFK", status:"live", statusDetail:"FL340",
    percent:62, middle:"2h 10m left", departs:"11:40", arrives:"14:50", gate:"B12", aircraft:"B772",
    altitude:"34,000", speed:"494", registration:"G-VIIL", terminal:"5", seat:"21A",
    timeline:[["Departed","11:48","LHR · Gate B12"],["Cruising","12:20","FL340 · over Cork"],["Descent","14:05","expected"],["Arrives","14:50","JFK · Terminal 7"]] },
  { id:"LH431", number:"LH431", airline:"Lufthansa", origin:"FRA", destination:"ORD",
    originCity:"Frankfurt", destinationCity:"Chicago O'Hare", status:"delayed", statusDetail:"22 min",
    percent:0, middle:"Departs 13:27", departs:"13:05", arrives:"15:40", gate:"A26", aircraft:"A35K",
    altitude:"—", speed:"—", registration:"D-AIXP", terminal:"1", seat:"14C",
    timeline:[["Delayed","13:27","new departure time"],["Boarding","12:55","Gate A26"],["Arrives","16:02","ORD · Terminal 1"]] },
  { id:"SQ317", number:"SQ317", airline:"Singapore Airlines", origin:"SIN", destination:"LHR",
    originCity:"Singapore Changi", destinationCity:"London Heathrow", status:"scheduled",
    percent:0, middle:"Departs 18:40", departs:"18:40", arrives:"01:10", gate:"C21", aircraft:"A388",
    altitude:"—", speed:"—", registration:"9V-SKU", terminal:"3", seat:"—",
    timeline:[["Scheduled","18:40","SIN · Gate C21"],["Arrives","01:10","LHR · Terminal 2"]] },
  { id:"AF1281", number:"AF1281", airline:"Air France", origin:"CDG", destination:"BCN",
    originCity:"Paris Charles de Gaulle", destinationCity:"Barcelona", status:"landed",
    percent:100, middle:"Landed 09:52", departs:"08:05", arrives:"09:52", gate:"D14", aircraft:"A220",
    altitude:"—", speed:"—", registration:"F-HZUC", terminal:"2F", seat:"—",
    timeline:[["Landed","09:52","BCN · 8 min early"],["Departed","08:05","CDG · Gate K42"]] }
];

const BOARD = [
  ["BA117","London Heathrow","11:40","B12","live","In air"],
  ["LH431","Frankfurt","13:05","A26","delayed","13:27"],
  ["SQ317","Singapore","18:40","C21","scheduled","On time"],
  ["AF1281","Paris CDG","08:05","D14","landed","Landed"],
  ["UA903","Newark","16:20","C88","ontime","On time"],
  ["EK7","Dubai","21:15","A9","scheduled","On time"],
  ["QF2","Sydney","06:05","B44","cancelled","Cancelled"]
];

const AIRPORTS = [
  ["LHR","London Heathrow","1,284 flights today","+4 min avg delay"],
  ["JFK","New York JFK","976 flights today","+11 min avg delay"],
  ["FRA","Frankfurt","1,102 flights today","On schedule"]
];

Object.assign(window, { FLIGHTS, BOARD, AIRPORTS });
