const { Icon, Logo, IconButton, Badge } = window.WingbeatDesignSystem_072965;

const SB_H = 54, HOME_H = 34, TAB_H = 64;

/* Abstract map ground: graticule + great-circle arcs. The production app renders
   vector map tiles here; the kit stands in with the brand's map palette. */
function MapGround({ children, height = "100%" }) {
  return (
    <div style={{ position: "absolute", inset: 0, height, background: "var(--surface-map)", overflow: "hidden" }}>
      <div style={{
        position: "absolute", inset: 0,
        backgroundImage: "linear-gradient(var(--sky-100) 1px,transparent 1px),linear-gradient(90deg,var(--sky-100) 1px,transparent 1px)",
        backgroundSize: "44px 44px"
      }} />
      <div style={{
        position: "absolute", inset: "-10% -20%",
        background: "radial-gradient(60% 45% at 30% 38%,var(--sky-100) 0%,rgba(230,241,250,0) 70%),radial-gradient(45% 40% at 78% 70%,var(--sky-100) 0%,rgba(230,241,250,0) 70%)"
      }} />
      <svg viewBox="0 0 402 620" style={{ position: "absolute", inset: 0, width: "100%", height: "100%" }}>
        <path d="M46 430 C 120 250, 250 180, 372 152" fill="none" stroke="var(--sky-400)" strokeWidth="2" strokeDasharray="6 7" opacity="0.85" />
        <path d="M46 430 C 96 340, 160 300, 214 272" fill="none" stroke="var(--sky-500)" strokeWidth="2.5" />
        <circle cx="46" cy="430" r="5" fill="var(--white)" stroke="var(--sky-600)" strokeWidth="2.5" />
        <circle cx="372" cy="152" r="5" fill="var(--white)" stroke="var(--sky-600)" strokeWidth="2.5" />
        <path d="M120 560 C 200 520, 280 470, 360 470" fill="none" stroke="var(--ink-200)" strokeWidth="2" strokeDasharray="5 6" />
      </svg>
      {children}
    </div>
  );
}

function PlaneMarker({ x, y, rotate = 0, active = false, label, onClick }) {
  return (
    <button onClick={onClick} style={{
      position: "absolute", left: x, top: y, transform: "translate(-50%,-50%)", border: 0,
      background: "transparent", padding: 0, cursor: "pointer", display: "flex",
      flexDirection: "column", alignItems: "center", gap: 4
    }}>
      <span style={{
        width: active ? 34 : 26, height: active ? 34 : 26, borderRadius: "var(--radius-full)",
        background: active ? "var(--dusk-500)" : "var(--surface-card)",
        boxShadow: active ? "var(--shadow-accent)" : "var(--shadow-sm)",
        border: active ? "none" : "1px solid var(--border-subtle)",
        display: "flex", alignItems: "center", justifyContent: "center",
        transform: `rotate(${rotate}deg)`, transition: "var(--transition-control)"
      }}>
        <Icon name="plane" size={active ? 18 : 14} color={active ? "#fff" : "var(--sky-600)"} />
      </span>
      {label ? (
        <span style={{
          fontFamily: "var(--font-mono)", fontSize: 10, fontWeight: 600, color: "var(--text-strong)",
          background: "var(--glass-bg)", backdropFilter: "var(--glass-blur)",
          padding: "2px 5px", borderRadius: 4, boxShadow: "var(--shadow-xs)"
        }}>{label}</span>
      ) : null}
    </button>
  );
}

function AppHeader({ onSearch, query }) {
  return (
    <div style={{
      paddingTop: SB_H, paddingLeft: "var(--pad-screen-x)", paddingRight: "var(--pad-screen-x)",
      paddingBottom: "var(--space-3)", background: "var(--glass-bg)",
      backdropFilter: "var(--glass-blur)", WebkitBackdropFilter: "var(--glass-blur)",
      borderBottom: "1px solid var(--border-subtle)", position: "relative", zIndex: 20
    }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "var(--space-3)" }}>
        <Logo size={22} />
        <div style={{ display: "flex", gap: 2, alignItems: "center" }}>
          <span style={{ position: "relative", display: "inline-flex" }}>
            <IconButton icon="bell" label="Alerts" />
            <span style={{ position: "absolute", top: 4, right: 4 }}><Badge count>2</Badge></span>
          </span>
          <IconButton icon="user-round" label="Account" />
        </div>
      </div>
      <div className="wb-input" onClick={onSearch} style={{ cursor: "text" }}>
        <span className="wb-input__affix"><Icon name="search" size={18} /></span>
        <input className="wb-input__el" placeholder="Flight number, route or airport" value={query} readOnly />
      </div>
    </div>
  );
}

function TabBar({ value, onChange }) {
  const items = [
    { id: "live", label: "Live", icon: "radio" },
    { id: "watchlist", label: "Watchlist", icon: "bookmark" },
    { id: "airports", label: "Airports", icon: "building-2" },
    { id: "alerts", label: "Alerts", icon: "bell" }
  ];
  return (
    <div style={{
      position: "absolute", left: 0, right: 0, bottom: 0, height: TAB_H + HOME_H,
      paddingBottom: HOME_H, display: "flex", background: "var(--glass-bg)",
      backdropFilter: "var(--glass-blur)", WebkitBackdropFilter: "var(--glass-blur)",
      borderTop: "1px solid var(--border-subtle)", zIndex: 40
    }}>
      {items.map((it) => {
        const on = it.id === value;
        return (
          <button key={it.id} onClick={() => onChange(it.id)} style={{
            flex: 1, border: 0, background: "transparent", cursor: "pointer", display: "flex",
            flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 3,
            minHeight: "var(--tap-min)", color: on ? "var(--sky-600)" : "var(--text-subtle)"
          }}>
            <Icon name={it.icon} size={22} />
            <span style={{
              fontFamily: "var(--font-ui)", fontSize: 11,
              fontWeight: on ? "var(--weight-bold)" : "var(--weight-medium)"
            }}>{it.label}</span>
          </button>
        );
      })}
    </div>
  );
}

function ScreenTitle({ children, action }) {
  return (
    <div style={{
      display: "flex", alignItems: "baseline", justifyContent: "space-between",
      padding: "var(--space-5) var(--pad-screen-x) var(--space-3)"
    }}>
      <h2 style={{ fontSize: "var(--size-2xl)", fontWeight: "var(--weight-bold)" }}>{children}</h2>
      {action}
    </div>
  );
}

Object.assign(window, { MapGround, PlaneMarker, AppHeader, TabBar, ScreenTitle, SB_H, HOME_H, TAB_H });
