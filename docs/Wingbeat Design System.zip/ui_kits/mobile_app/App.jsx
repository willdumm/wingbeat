const { Toast } = window.WingbeatDesignSystem_072965;

function App() {
  const [tab, setTab] = React.useState("live");
  const [detail, setDetail] = React.useState(null);
  const [toast, setToast] = React.useState(false);

  React.useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(false), 3200);
    return () => clearTimeout(t);
  }, [toast]);

  const open = (id) => setDetail(id);

  return (
    <IOSDevice width={402} height={874}>
      <div style={{ position: "absolute", inset: 0, overflow: "hidden", background: "var(--surface-page)", fontFamily: "var(--font-body)" }}>
        {detail ? (
          <DetailScreen id={detail} onBack={() => setDetail(null)} onToast={() => setToast(true)} />
        ) : (
          <>
            {tab === "live" && <LiveScreen onOpen={open} onSearch={() => setTab("watchlist")} />}
            {tab === "watchlist" && <WatchlistScreen onOpen={open} />}
            {tab === "airports" && <AirportsScreen />}
            {tab === "alerts" && <AlertsScreen />}
            <TabBar value={tab} onChange={setTab} />
          </>
        )}
        {toast ? (
          <div style={{ position: "absolute", left: 16, right: 16, bottom: HOME_H + 16, zIndex: 80 }}>
            <Toast tone="info" title="Tracking BA117" message="We'll alert you on gate and delay changes." />
          </div>
        ) : null}
      </div>
    </IOSDevice>
  );
}

Object.assign(window, { App });
