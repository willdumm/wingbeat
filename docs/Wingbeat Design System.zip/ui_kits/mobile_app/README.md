# Wingbeat for iOS — UI kit

A click-through recreation of the Wingbeat mobile tracker at 402×874 (iPhone 16 logical size), built entirely from this design system's primitives.

## Screens
| File | Screen | Notes |
| --- | --- | --- |
| `Screens.jsx` | **Live** | Map ground, tappable aircraft markers, glass map controls, bottom flight card. Tap a marker to switch the card; "Details" opens the detail screen. |
| `Screens.jsx` | **Watchlist** | Pill tabs (All / Active) over a stack of `FlightCard`s. |
| `Screens.jsx` | **Airports** | Airport rows with mono IATA badges and status chips. |
| `Detail.jsx` | **Flight detail** | Map header with scrim label, route bar, six-stat grid, timeline, alert actions, confirm dialog. |
| `Detail.jsx` | **Alerts** | Toast history plus notification settings (switch, checkboxes, select, radios, quiet hours). |
| `Chrome.jsx` | App chrome | Glass header with logo + search, bottom tab bar, map ground, plane markers, screen titles. |
| `App.jsx` | Shell | Tab state, detail routing, transient toast. |
| `data.js` | Fixtures | Four flights with timelines; `window.FLIGHTS`. |
| `ios-frame.jsx` | Device bezel | Starter component (status bar, dynamic island, home indicator). |

## Interactions that work
Tab bar navigation · marker selection on the live map · open/close flight detail · "Alert me" toast · stop-tracking dialog · all settings controls · pill tab filtering.

## Deliberately absent
Real map tiles. The map is an abstract graticule with great-circle arcs in the brand's map palette — production renders vector tiles here. No map vendor or style was supplied.
