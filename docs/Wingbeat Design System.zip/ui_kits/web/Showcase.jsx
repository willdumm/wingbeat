const { Button, Icon, Card, Badge, Tag, Stat } = window.WingbeatDesignSystem_072965;

function SectionHead({ overline, title, body, align = "start" }) {
  return (
    <div style={{ maxWidth: "64ch", marginBottom: "var(--space-10)", marginInline: align === "center" ? "auto" : undefined, textAlign: align === "center" ? "center" : undefined }}>
      <span className="wb-overline">{overline}</span>
      <h2 style={{ fontSize: "var(--size-3xl)", lineHeight: "var(--leading-tight)", letterSpacing: "var(--tracking-heading)", fontWeight: "var(--weight-bold)", margin: "var(--space-3) 0 var(--space-4)", textWrap: "balance" }}>{title}</h2>
      {body ? <p style={{ ...BODY, fontSize: "var(--size-lg)", lineHeight: "var(--leading-relaxed)" }}>{body}</p> : null}
    </div>
  );
}

function OpenSource() {
  return (
    <section id="open-source" style={{ background: "var(--surface-page)", borderTop: "1px solid var(--border-subtle)", borderBottom: "1px solid var(--border-subtle)" }}>
      <div style={{ ...SECTION_MAX, display: "grid", gridTemplateColumns: "minmax(0,1fr) minmax(0,1fr)", gap: "var(--space-16)", alignItems: "center" }}>
        <div>
          <SectionHead
            overline="AGPL-3.0"
            title="The whole tracker is open source."
            body="Every line that polls Garmin, segments flights and draws the map is public. Read it before you trust it with your fleet, run it on your own Cloudflare account, and fork it if you need something we haven't built."
          />
          <div style={{ display: "flex", flexDirection: "column", gap: "var(--space-3)" }}>
            {[
              ["file-code", "One Worker and one SQLite database — no build server, no container to babysit."],
              ["database", "Your tracking data stays in your D1 database. Export or delete it whenever you want."],
              ["git-pull-request", "Pull requests welcome. Contributors sign a CLA and keep ownership of their work."]
            ].map(([icon, text]) => (
              <div key={text} style={{ display: "flex", gap: "var(--space-3)", alignItems: "flex-start" }}>
                <Icon name={icon} size={20} color="var(--sky-600)" />
                <p style={{ ...BODY, fontSize: "var(--size-md)" }}>{text}</p>
              </div>
            ))}
          </div>
          <div style={{ display: "flex", gap: "var(--space-3)", marginTop: "var(--space-8)", flexWrap: "wrap" }}>
            <Button variant="primary" icon="code" href="https://github.com/willdumm/wingbeat">Read the source</Button>
            <Button variant="ghost" href="#docs">Self-hosting guide</Button>
          </div>
        </div>
        <Card padding="none" elevation="raised">
          <div style={{ display: "flex", alignItems: "center", gap: "var(--space-2)", padding: "var(--space-4) var(--pad-card)", borderBottom: "1px solid var(--border-subtle)" }}>
            <Icon name="terminal" size={16} color="var(--text-subtle)" />
            <span className="wb-overline">Deploy your own</span>
          </div>
          <div className="wb-mono" style={{ padding: "var(--pad-card)", fontSize: "var(--size-sm)", lineHeight: 2, color: "var(--text-body)", background: "var(--surface-page)", overflowX: "auto" }}>
            {[
              ["$", "wrangler d1 create flight-tracker-db"],
              ["$", "wrangler d1 migrations apply flight-tracker-db"],
              ["$", "wrangler secret put POLLER_SECRET"],
              ["$", "npm run deploy"]
            ].map(([p, cmd]) => (
              <div key={cmd} style={{ whiteSpace: "pre" }}>
                <span style={{ color: "var(--text-subtle)" }}>{p} </span>{cmd}
              </div>
            ))}
            <div style={{ whiteSpace: "pre", color: "var(--text-subtle)" }}># then open Settings and add a tracker</div>
          </div>
        </Card>
      </div>
    </section>
  );
}

const FEATURES = [
  ["plane", "Flights, not points", "Position reports are segmented into flights automatically. Takeoff and landing are detected from velocity — nobody types a time into a form."],
  ["map-pin", "Places, not coordinates", "Boundary points are reverse-geocoded, so history reads Kodiak → Larsen Bay instead of two decimal pairs. Named points and regions you define are drawn on the map too."],
  ["bell", "Takeoff, landing and signal gaps", "Notifications fire the moment an aircraft leaves the ground, lands, or goes quiet in flight for longer than your gap threshold. Pushover natively, or a JSON webhook to anything else."],
  ["layers", "Four basemaps", "Topo, USGS, satellite and street tiles. Terrain matters when the route is a fjord, so the map is built to switch."],
  ["building-2", "Aircraft, pilots and trackers", "All three are records, not labels. Move a tracker to another airframe and the flight history follows the aircraft, not the device."],
  ["sliders-horizontal", "Configured in the browser", "App name, timezone, default map view, gap threshold and notification targets are all settings. No redeploy to change a name."],
  ["users", "Invite-only accounts", "Admins and viewers, sessions stored in your own database. No public sign-up and no third-party identity provider in the path."],
  ["radio", "Built for the hardware you have", "Garmin inReach over MapShare today, polled once a minute and throttled to the device's transmission rate. The poller is factored so other tracker types can be added."]
];

function Features() {
  return (
    <section id="features" style={SECTION_MAX}>
      <SectionHead
        overline="Features"
        title="What it does with a position report."
        body="An inReach sends a point every couple of minutes. Everything below is what the tracker builds out of that stream."
      />
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4,minmax(0,1fr))", gap: "var(--space-6)" }}>
        {FEATURES.map(([icon, title, body]) => (
          <Card key={title} padding="lg">
            <span style={{ display: "inline-flex", width: 40, height: 40, borderRadius: "var(--radius-md)", background: "var(--surface-brand-soft)", alignItems: "center", justifyContent: "center", marginBottom: "var(--space-4)" }}>
              <Icon name={icon} size={20} color="var(--sky-600)" />
            </span>
            <h3 style={{ fontSize: "var(--size-lg)", fontWeight: "var(--weight-bold)", marginBottom: "var(--space-2)" }}>{title}</h3>
            <p style={BODY}>{body}</p>
          </Card>
        ))}
      </div>
    </section>
  );
}

const STEPS = [
  ["01", "The inReach transmits", "Your pilots carry the device they already fly with. MapShare publishes its position roughly every two minutes."],
  ["02", "The Worker polls the feed", "A cron trigger runs every minute, fetches each tracker's KML feed, and writes new points into your D1 database."],
  ["03", "Points become flights", "Segmentation groups the stream into flights, geocodes the endpoints, and the dashboard draws the track. Notifications go out as events are detected."]
];

function HowItWorks() {
  return (
    <section id="how" style={{ background: "var(--surface-page)", borderTop: "1px solid var(--border-subtle)", borderBottom: "1px solid var(--border-subtle)" }}>
      <div style={SECTION_MAX}>
        <SectionHead overline="How it works" title="Three moving parts between the aircraft and the map." />
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3,minmax(0,1fr))", gap: "var(--space-6)" }}>
          {STEPS.map(([n, title, body]) => (
            <Card key={n} padding="lg">
              <span className="wb-mono" style={{ fontSize: "var(--size-xl)", fontWeight: 600, color: "var(--sky-500)" }}>{n}</span>
              <h3 style={{ fontSize: "var(--size-lg)", fontWeight: "var(--weight-bold)", margin: "var(--space-3) 0 var(--space-2)" }}>{title}</h3>
              <p style={BODY}>{body}</p>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}

const PLANS = [
  {
    name: "Self-host", price: "Free", note: "AGPL-3.0",
    body: "You deploy the Worker, create the database and add your trackers. Fine for personal, club or internal use, or any deployment that publishes its source.",
    points: ["Full feature set, no limits", "Your Cloudflare account and data", "Community support on GitHub"],
    cta: "Read the setup guide", href: "#docs", variant: "secondary"
  },
  {
    name: "Hosted", price: "Talk to us", note: "Managed", featured: true,
    body: "We run the deployment, connect your inReach feeds, and keep it updated. You get a domain, an admin account and someone to call when a tracker stops reporting.",
    points: ["Setup and tracker onboarding included", "Updates, monitoring and backups", "Notification targets configured for your crew"],
    cta: "Get in touch", href: "mailto:hello@example.com", variant: "accent"
  },
  {
    name: "Commercial license", price: "Talk to us", note: "Dual-licensed",
    body: "For operators who want to run the software as a paid service for their own customers, or inside a closed-source product, without the AGPL's source-disclosure obligation.",
    points: ["No network-copyleft obligation", "Closed operator layer permitted", "Support terms negotiated separately"],
    cta: "Ask about licensing", href: "mailto:hello@example.com", variant: "secondary"
  }
];

function Hosting() {
  return (
    <section id="hosting" style={SECTION_MAX}>
      <SectionHead
        align="center"
        overline="Hosting"
        title="Run it yourself, or let us run it."
        body="The software is the same in every column. What changes is who keeps it running and which licence you need."
      />
      <div style={{ display: "grid", gridTemplateColumns: "repeat(3,minmax(0,1fr))", gap: "var(--space-6)", alignItems: "start" }}>
        {PLANS.map((p) => (
          <Card key={p.name} padding="lg" elevation={p.featured ? "raised" : "default"}>
            <div style={{ display: "flex", alignItems: "center", gap: "var(--space-3)", minHeight: 52, alignItems: "flex-start", flexWrap: "wrap" }}>
              <h3 style={{ fontSize: "var(--size-lg)", fontWeight: "var(--weight-bold)" }}>{p.name}</h3>
              {p.featured ? <Badge tone="accent">{p.note}</Badge> : <Badge>{p.note}</Badge>}
            </div>
            <div className="wb-mono" style={{ fontSize: "var(--size-2xl)", fontWeight: 600, margin: "var(--space-4) 0 var(--space-4)" }}>{p.price}</div>
            <p style={{ ...BODY, minHeight: "7.5em" }}>{p.body}</p>
            <div style={{ display: "flex", flexDirection: "column", gap: "var(--space-2)", margin: "var(--space-5) 0 var(--space-6)" }}>
              {p.points.map((pt) => (
                <div key={pt} style={{ display: "flex", gap: "var(--space-2)", alignItems: "flex-start" }}>
                  <Icon name="check" size={16} color="var(--ontime-500)" />
                  <span style={{ fontFamily: "var(--font-body)", fontSize: "var(--size-sm)", lineHeight: "var(--leading-normal)", color: "var(--text-body)" }}>{pt}</span>
                </div>
              ))}
            </div>
            <Button variant={p.variant} fullWidth href={p.href}>{p.cta}</Button>
          </Card>
        ))}
      </div>
      <p style={{ ...BODY, fontSize: "var(--size-sm)", textAlign: "center", marginTop: "var(--space-6)" }}>
        Not sure which one you need? The AGPL only asks you to publish your source if you run a modified version as a network service.
      </p>
    </section>
  );
}

function DocsBand() {
  return (
    <section id="docs" style={{ background: "var(--surface-brand)", color: "var(--text-inverse)" }}>
      <div style={{ ...SECTION_MAX, display: "grid", gridTemplateColumns: "minmax(0,1.2fr) minmax(0,1fr)", gap: "var(--space-16)", alignItems: "center" }}>
        <div>
          <span className="wb-overline" style={{ color: "var(--sky-100)" }}>Documentation</span>
          <h2 style={{ fontSize: "var(--size-3xl)", lineHeight: "var(--leading-tight)", letterSpacing: "var(--tracking-heading)", fontWeight: "var(--weight-bold)", color: "var(--text-inverse)", margin: "var(--space-3) 0 var(--space-4)" }}>
            Setup, tracker onboarding, every API route.
          </h2>
          <p style={{ fontFamily: "var(--font-body)", fontSize: "var(--size-lg)", lineHeight: "var(--leading-relaxed)", color: "var(--sky-100)", maxWidth: "50ch", margin: 0 }}>
            Deploying your own instance, pointing a Garmin MapShare feed at it, adding pilots and aircraft, and wiring up notifications — written for the person doing it, not the person who wrote it.
          </p>
          <div style={{ marginTop: "var(--space-8)" }}>
            <Button variant="inverse" size="lg" iconAfter="arrow-right" href="#docs">Open the docs</Button>
          </div>
        </div>
        <div style={{ display: "grid", gap: "var(--space-3)" }}>
          {["Deploy to Cloudflare", "Get your MapShare feed URL", "Add aircraft, pilots and trackers", "Notification targets", "API reference"].map((t) => (
            <a key={t} href="#docs" style={{
              display: "flex", alignItems: "center", justifyContent: "space-between", gap: "var(--space-4)",
              padding: "var(--space-4) var(--space-5)", borderRadius: "var(--radius-md)",
              background: "var(--sky-600)", border: "1px solid var(--sky-400)",
              fontFamily: "var(--font-ui)", fontSize: "var(--size-md)", fontWeight: 600,
              color: "var(--text-inverse)", textDecoration: "none"
            }}>
              {t}<Icon name="chevron-right" size={16} />
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}

Object.assign(window, { SectionHead, OpenSource, Features, HowItWorks, Hosting, DocsBand });
