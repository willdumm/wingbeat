# Web — showcase page

`index.html` is the single-page product site. Sections in order: sticky glass header, hero,
features (8 cards), how it works (3 steps), open source, hosting options (3 plans), docs band,
footer. Nav items are in-page anchors.

- `Site.jsx` — `SiteHeader`, `Hero`, `SiteFooter`, plus the shared `SECTION_MAX` / `BODY` style
  constants the other file reads off `window`.
- `Showcase.jsx` — `SectionHead`, `Features`, `HowItWorks`, `OpenSource`, `Hosting`, `DocsBand`.

Content is derived from the `willdumm/wingbeat` README and licence docs (see
`github.md`). Two things are placeholders, not facts: the contact address on the hosting CTAs
(`mailto:hello@example.com`) and the "Talk to us" prices. The docs band links to `#docs` — point it
at the Hugo documentation site once it exists.

Every value comes from tokens; no colours, sizes or radii are hard-coded.
