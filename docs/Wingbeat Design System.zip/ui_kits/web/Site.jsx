const { Logo, Button, Icon, Card, Badge, Tag, FlightStatusBadge, Stat } = window.WingbeatDesignSystem_072965;

const SECTION_MAX = { maxWidth: "var(--content-max)", margin: "0 auto", padding: "var(--space-20) var(--pad-page-x)" };
const BODY = { fontFamily: "var(--font-body)", fontSize: "var(--size-md)", lineHeight: "var(--leading-normal)", color: "var(--text-muted)", margin: 0 };

function SiteHeader() {
  const nav = [["Features", "#features"], ["How it works", "#how"], ["Open source", "#open-source"], ["Hosting", "#hosting"]];
  return (
    <header style={{
      position: "sticky", top: 0, zIndex: 30, background: "var(--glass-bg)",
      backdropFilter: "var(--glass-blur)", WebkitBackdropFilter: "var(--glass-blur)",
      borderBottom: "1px solid var(--border-subtle)"
    }}>
      <div style={{ maxWidth: "var(--content-max)", margin: "0 auto", padding: "0 var(--pad-page-x)", height: 68, display: "flex", alignItems: "center", gap: "var(--space-8)" }}>
        <Logo size={24} />
        <nav style={{ display: "flex", gap: "var(--space-6)" }}>
          {nav.map(([label, href]) => (
            <a key={label} href={href} style={{
              fontFamily: "var(--font-ui)", fontSize: "var(--size-md)", fontWeight: 600,
              color: "var(--text-muted)", textDecoration: "none", padding: "6px 0"
            }}>{label}</a>
          ))}
        </nav>
        <div style={{ marginLeft: "auto", display: "flex", alignItems: "center", gap: "var(--space-3)" }}>
          <Button variant="ghost" size="md" href="#docs">Docs</Button>
          <Button variant="primary" size="md" href="#hosting">Hosting options</Button>
        </div>
      </div>
    </header>
  );
}

const FLEET = [
  { tail: "N728SH", status: "live", detail: "14:50", route: "Kodiak → Larsen Bay", telemetry: "57.790, -152.410 · 1,400 ft · 96 kt", time: "14:50" },
  { tail: "N512KD", status: "landed", detail: "09:52", route: "Port Lions → Kodiak", telemetry: "Blocked in · 28 min flight", time: "09:52" },
  { tail: "N904AK", status: "scheduled", detail: "15:20", route: "Kodiak → Old Harbor", telemetry: "Tracker online · last report 14:46", time: "15:20" }
];

function Hero() {
  return (
    <section style={{ position: "relative", overflow: "hidden", background: "var(--sky-50)", borderBottom: "1px solid var(--border-subtle)" }}>
      <div style={{
        position: "absolute", inset: 0,
        backgroundImage: "linear-gradient(var(--sky-100) 1px,transparent 1px),linear-gradient(90deg,var(--sky-100) 1px,transparent 1px)",
        backgroundSize: "56px 56px", opacity: 0.9
      }} />
      <svg viewBox="0 0 1280 420" style={{ position: "absolute", inset: 0, width: "100%", height: "100%" }}>
        <path d="M-40 380 C 300 300, 620 150, 1320 60" fill="none" stroke="var(--sky-300)" strokeWidth="2" strokeDasharray="8 9" />
        <path d="M-40 430 C 380 400, 700 330, 1320 200" fill="none" stroke="var(--sky-200)" strokeWidth="2" />
      </svg>
      <div style={{
        position: "relative", maxWidth: "var(--content-max)", margin: "0 auto",
        padding: "var(--space-24) var(--pad-page-x)", display: "grid",
        gridTemplateColumns: "minmax(0,1.05fr) minmax(0,0.95fr)", gap: "var(--space-16)", alignItems: "center"
      }}>
        <div>
          <span className="wb-overline" style={{ color: "var(--dusk-600)" }}>Open source · AGPL-3.0</span>
          <h1 style={{ fontSize: "var(--size-5xl)", lineHeight: "var(--leading-tight)", letterSpacing: "var(--tracking-display)", fontWeight: "var(--weight-extrabold)", margin: "var(--space-4) 0 var(--space-5)", textWrap: "balance" }}>
            Know where the aircraft is.
          </h1>
          <p style={{ ...BODY, fontSize: "var(--size-lg)", lineHeight: "var(--leading-relaxed)", maxWidth: "48ch" }}>
            Flight tracking for small air taxi operations, built on the Garmin inReach your pilots already carry. It polls the MapShare feed, turns position reports into flights, and puts the whole fleet on one map. Host it yourself or let us run it.
          </p>
          <div style={{ display: "flex", gap: "var(--space-3)", marginTop: "var(--space-8)", flexWrap: "wrap" }}>
            <Button size="lg" variant="primary" href="#hosting">See hosting options</Button>
            <Button size="lg" variant="secondary" icon="code" href="https://github.com/willdumm/wingbeat">Read the source</Button>
          </div>
          <div style={{ display: "flex", gap: "var(--space-2)", marginTop: "var(--space-5)", flexWrap: "wrap" }}>
            {["Garmin inReach", "Cloudflare Workers + D1", "No app to install"].map((t) => <Tag key={t}>{t}</Tag>)}
          </div>
        </div>
        <Card padding="lg" elevation="raised">
          <div style={{ display: "flex", alignItems: "center", gap: "var(--space-3)", marginBottom: "var(--space-5)" }}>
            <span className="wb-overline">Fleet · 3 aircraft</span>
            <span className="wb-mono" style={{ marginLeft: "auto", fontSize: "var(--size-xs)", color: "var(--text-subtle)" }}>14:51</span>
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: "var(--space-4)" }}>
            {FLEET.map((f) => (
              <div key={f.tail} style={{ display: "flex", alignItems: "flex-start", gap: "var(--space-4)", paddingBottom: "var(--space-4)", borderBottom: "1px solid var(--border-subtle)" }}>
                <div style={{ minWidth: 0, flex: 1 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: "var(--space-3)" }}>
                    <span className="wb-mono" style={{ fontSize: "var(--size-md)", fontWeight: 600 }}>{f.tail}</span>
                    <FlightStatusBadge status={f.status} detail={f.detail} />
                  </div>
                  <div style={{ fontFamily: "var(--font-ui)", fontSize: "var(--size-sm)", fontWeight: 600, marginTop: "var(--space-2)" }}>{f.route}</div>
                  <div className="wb-mono" style={{ fontSize: "var(--size-xs)", color: "var(--text-subtle)", marginTop: 2 }}>{f.telemetry}</div>
                </div>
              </div>
            ))}
          </div>
          <div style={{ display: "flex", gap: "var(--space-8)", marginTop: "var(--space-4)" }}>
            <Stat label="Feed polled" value="60" unit="s" />
            <Stat label="Flights logged" value="1,284" />
            <Stat label="Your data" value="D1" />
          </div>
        </Card>
      </div>
    </section>
  );
}

function SiteFooter() {
  const cols = [
    ["Product", [["Features", "#features"], ["How it works", "#how"], ["Hosting", "#hosting"]]],
    ["Documentation", [["Setup", "#docs"], ["Add a tracker", "#docs"], ["Notifications", "#docs"], ["API routes", "#docs"]]],
    ["Project", [["GitHub", "https://github.com/willdumm/wingbeat"], ["AGPL-3.0", "#open-source"], ["Commercial license", "#hosting"], ["Contributing", "#open-source"]]]
  ];
  return (
    <footer style={{ background: "var(--surface-inverse)", color: "var(--ink-300)" }}>
      <div style={{ maxWidth: "var(--content-max)", margin: "0 auto", padding: "var(--space-16) var(--pad-page-x)", display: "grid", gridTemplateColumns: "minmax(0,1.4fr) repeat(3,minmax(0,1fr))", gap: "var(--space-10)" }}>
        <div>
          <Logo size={22} tone="mono-white" />
          <p style={{ fontFamily: "var(--font-body)", fontSize: "var(--size-sm)", lineHeight: "var(--leading-normal)", color: "var(--ink-400)", maxWidth: "34ch", marginTop: "var(--space-4)" }}>
            Fleet tracking for operators who fly where the coverage ends.
          </p>
        </div>
        {cols.map(([head, links]) => (
          <div key={head}>
            <span className="wb-overline" style={{ color: "var(--ink-400)" }}>{head}</span>
            <div style={{ display: "flex", flexDirection: "column", gap: "var(--space-2)", marginTop: "var(--space-3)" }}>
              {links.map(([l, href]) => (
                <a key={l} href={href} style={{ fontFamily: "var(--font-body)", fontSize: "var(--size-md)", color: "var(--ink-200)" }}>{l}</a>
              ))}
            </div>
          </div>
        ))}
      </div>
      <div style={{ borderTop: "1px solid var(--ink-800)" }}>
        <div style={{ maxWidth: "var(--content-max)", margin: "0 auto", padding: "var(--space-5) var(--pad-page-x)", display: "flex", justifyContent: "space-between", fontFamily: "var(--font-body)", fontSize: "var(--size-xs)", color: "var(--ink-500)" }}>
          <span>© 2026 Wingbeat</span>
          <span className="wb-mono">AGPL-3.0 · Garmin inReach · Cloudflare Workers + D1</span>
        </div>
      </div>
    </footer>
  );
}

Object.assign(window, { SiteHeader, Hero, SiteFooter, SECTION_MAX, BODY });
